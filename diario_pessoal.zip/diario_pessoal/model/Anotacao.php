<?php

class Anotacao {

    //Atributos
    private ?int $id;
    private ?string $data;
    private ?string $titulo;
    private ?string $texto;
    private array $imagens;

    //Construtor
    public function __construct($id=0, $data=null, $titulo=null, $texto=null, $imagens=array()) {
        $this->id = $id;
        $this->data = $data;
        $this->titulo = $titulo;
        $this->texto = $texto;
        $this->imagens = $imagens;
    }

    //GETs e SETs
    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): self {
        $this->id = $id;
        return $this;
    }

    public function getData(): ?string {
        return $this->data;
    }

    public function setData(?string $data): self {
        $this->data = $data;
        return $this;
    }

    public function getTitulo(): ?string {
        return $this->titulo;
    }

    public function setTitulo(?string $titulo): self {
        $this->titulo = $titulo;
        return $this;
    }

    public function getTexto(): ?string {
        return $this->texto;
    }

    public function setTexto(?string $texto): self {
        $this->texto = $texto;
        return $this;
    }

    public function getImagens(): array {
        return $this->imagens;
    }

    public function setImagens(array $imagens): self {
        $this->imagens = $imagens;
        return $this;
    }

    public function getDataFormatada(): string {
        if(! $this->data)
            return "";

        return date("d/m/Y", strtotime($this->data));
    }
}
