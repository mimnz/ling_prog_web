<?php

class Usuario {

    //Atributos
    private ?string $login;
    private ?string $nome;
    private ?string $senha;
    private ?string $tipo;
    private array $anotacoes;

    //Construtor
    public function __construct($login=null, $nome=null, $senha=null, $tipo='usuario', $anotacoes=array()) {
        $this->login = $login;
        $this->nome = $nome;
        $this->senha = $senha;
        $this->tipo = $tipo;
        $this->anotacoes = $anotacoes;
    }

    //GETs e SETs
    public function getLogin(): ?string {
        return $this->login;
    }

    public function setLogin(?string $login): self {
        $this->login = $login;
        return $this;
    }

    public function getNome(): ?string {
        return $this->nome;
    }

    public function setNome(?string $nome): self {
        $this->nome = $nome;
        return $this;
    }

    public function getSenha(): ?string {
        return $this->senha;
    }

    public function setSenha(?string $senha): self {
        $this->senha = $senha;
        return $this;
    }

    public function getTipo(): ?string {
        return $this->tipo;
    }

    public function setTipo(?string $tipo): self {
        $this->tipo = $tipo;
        return $this;
    }

    public function getAnotacoes(): array {
        return $this->anotacoes;
    }

    public function setAnotacoes(array $anotacoes): self {
        $this->anotacoes = $anotacoes;
        return $this;
    }

    public function isAdmin(): bool {
        return $this->tipo == 'adm';
    }
}
