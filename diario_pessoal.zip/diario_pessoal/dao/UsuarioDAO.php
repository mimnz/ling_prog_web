<?php

require_once(__DIR__ . "/../model/Usuario.php");

class UsuarioDAO {

    public function insert(Usuario $usuario) {
        if(! isset($_SESSION['diario']))
            return "Sessão não existe!";

        $login = $usuario->getLogin();

        if(isset($_SESSION['diario']['usuarios'][$login]))
            return "Este login já está em uso.";

        $_SESSION['diario']['usuarios'][$login] = array(
            'login' => $usuario->getLogin(),
            'nome' => $usuario->getNome(),
            'senha' => $usuario->getSenha(),
            'tipo' => $usuario->getTipo(),
            'anotacoes' => $usuario->getAnotacoes()
        );

        return "";
    }

    public function list() {
        if(! isset($_SESSION['diario']['usuarios']))
            return array();

        return $this->map($_SESSION['diario']['usuarios']);
    }

    public function findByLogin(string $login): ?Usuario {
        if(! isset($_SESSION['diario']['usuarios'][$login]))
            return NULL;

        $dados = array($_SESSION['diario']['usuarios'][$login]);
        $usuarios = $this->map($dados);

        if(! empty($usuarios))
            return $usuarios[0];

        return NULL;
    }

    public function delete(string $login) {
        if(! isset($_SESSION['diario']))
            return "Sessão não existe!";

        if(! isset($_SESSION['diario']['usuarios'][$login]))
            return "Perfil não encontrado.";

        unset($_SESSION['diario']['usuarios'][$login]);

        if(isset($_SESSION['diario']['usuario_ativo']) && $_SESSION['diario']['usuario_ativo'] == $login)
            $_SESSION['diario']['usuario_ativo'] = NULL;

        return "";
    }

    public function setUsuarioAtivo(string $login) {
        if(! isset($_SESSION['diario']['usuarios'][$login]))
            return "Perfil não encontrado.";

        $_SESSION['diario']['usuario_ativo'] = $login;
        return "";
    }

    public function clearUsuarioAtivo() {
        if(isset($_SESSION['diario']))
            $_SESSION['diario']['usuario_ativo'] = NULL;
    }

    public function getUsuarioAtivo(): ?Usuario {
        if(! isset($_SESSION['diario']['usuario_ativo']))
            return NULL;

        $login = $_SESSION['diario']['usuario_ativo'];

        if(! $login)
            return NULL;

        return $this->findByLogin($login);
    }

    private function map(array $dados) {
        $usuarios = array();

        foreach($dados as $d) {
            $usuario = new Usuario();
            $usuario->setLogin($d['login']);
            $usuario->setNome($d['nome']);
            $usuario->setSenha($d['senha']);
            $usuario->setTipo($d['tipo']);
            $usuario->setAnotacoes($d['anotacoes']);

            array_push($usuarios, $usuario);
        }

        return $usuarios;
    }
}
