<?php

require_once(__DIR__ . "/../model/Usuario.php");

class SessaoDAO {

    public function existe(): bool {
        return isset($_SESSION['diario']);
    }

    public function criarEstrutura(string $senhaAdmin) {
        if($this->existe())
            return "O diário já foi iniciado nesta sessão.";

        $admin = new Usuario();
        $admin->setLogin("adm");
        $admin->setNome("Administrador");
        $admin->setSenha($senhaAdmin);
        $admin->setTipo("adm");
        $admin->setAnotacoes(array());

        $_SESSION['diario'] = array(
            'usuarios' => array(
                'adm' => array(
                    'login' => $admin->getLogin(),
                    'nome' => $admin->getNome(),
                    'senha' => $admin->getSenha(),
                    'tipo' => $admin->getTipo(),
                    'anotacoes' => $admin->getAnotacoes()
                )
            ),
            'usuario_ativo' => NULL
        );

        return "";
    }

    public function exibir() {
        if($this->existe())
            return $_SESSION['diario'];

        return NULL;
    }

    public function destruir() {
        session_unset();
        session_destroy();
    }
}
