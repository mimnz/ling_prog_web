<?php

require_once(__DIR__ . "/../model/Anotacao.php");

class AnotacaoDAO {

    public function insert(Anotacao $anotacao) {
        if(! isset($_SESSION['diario']))
            return "Sessão não existe!";

        $login = $this->getLoginUsuarioAtivo();
        if(! $login)
            return "Nenhum perfil está autenticado.";

        $anotacoes = $_SESSION['diario']['usuarios'][$login]['anotacoes'];

        $maiorId = 0;
        foreach($anotacoes as $a) {
            if($a['id'] > $maiorId)
                $maiorId = $a['id'];
        }

        $anotacao->setId($maiorId + 1);

        array_push($_SESSION['diario']['usuarios'][$login]['anotacoes'], array(
            'id' => $anotacao->getId(),
            'data' => $anotacao->getData(),
            'titulo' => $anotacao->getTitulo(),
            'texto' => $anotacao->getTexto(),
            'imagens' => $anotacao->getImagens()
        ));

        return "";
    }

    public function list() {
        $login = $this->getLoginUsuarioAtivo();
        if(! $login)
            return array();

        $dados = $_SESSION['diario']['usuarios'][$login]['anotacoes'];
        $anotacoes = $this->map($dados);

        //Ordenar pelas anotações mais recentes
        usort($anotacoes, function($a, $b) {
            if($a->getData() == $b->getData())
                return $b->getId() - $a->getId();

            return strcmp($b->getData(), $a->getData());
        });

        return $anotacoes;
    }

    public function findById(int $id): ?Anotacao {
        $login = $this->getLoginUsuarioAtivo();
        if(! $login)
            return NULL;

        $dados = $_SESSION['diario']['usuarios'][$login]['anotacoes'];

        foreach($dados as $d) {
            if($d['id'] == $id) {
                $anotacoes = $this->map(array($d));
                return $anotacoes[0];
            }
        }

        return NULL;
    }

    public function update(Anotacao $anotacao) {
        $login = $this->getLoginUsuarioAtivo();
        if(! $login)
            return "Nenhum perfil está autenticado.";

        $anotacoes = $_SESSION['diario']['usuarios'][$login]['anotacoes'];

        foreach($anotacoes as $indice => $a) {
            if($a['id'] == $anotacao->getId()) {
                $_SESSION['diario']['usuarios'][$login]['anotacoes'][$indice] = array(
                    'id' => $anotacao->getId(),
                    'data' => $anotacao->getData(),
                    'titulo' => $anotacao->getTitulo(),
                    'texto' => $anotacao->getTexto(),
                    'imagens' => $anotacao->getImagens()
                );
                return "";
            }
        }

        return "Anotação não encontrada.";
    }

    public function delete(int $id) {
        $login = $this->getLoginUsuarioAtivo();
        if(! $login)
            return "Nenhum perfil está autenticado.";

        $anotacoes = $_SESSION['diario']['usuarios'][$login]['anotacoes'];

        foreach($anotacoes as $indice => $a) {
            if($a['id'] == $id) {
                unset($_SESSION['diario']['usuarios'][$login]['anotacoes'][$indice]);
                $_SESSION['diario']['usuarios'][$login]['anotacoes'] = array_values(
                    $_SESSION['diario']['usuarios'][$login]['anotacoes']
                );
                return "";
            }
        }

        return "Anotação não encontrada.";
    }

    private function getLoginUsuarioAtivo() {
        if(isset($_SESSION['diario']['usuario_ativo']))
            return $_SESSION['diario']['usuario_ativo'];

        return NULL;
    }

    private function map(array $dados) {
        $anotacoes = array();

        foreach($dados as $d) {
            $anotacao = new Anotacao();
            $anotacao->setId($d['id']);
            $anotacao->setData($d['data']);
            $anotacao->setTitulo($d['titulo']);
            $anotacao->setTexto($d['texto']);
            $anotacao->setImagens($d['imagens']);

            array_push($anotacoes, $anotacao);
        }

        return $anotacoes;
    }
}
