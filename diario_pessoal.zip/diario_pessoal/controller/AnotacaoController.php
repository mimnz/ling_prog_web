<?php

require_once(__DIR__ . "/../dao/AnotacaoDAO.php");
require_once(__DIR__ . "/../service/AnotacaoService.php");
require_once(__DIR__ . "/../util/ImagemUtil.php");

class AnotacaoController {

    private AnotacaoDAO $anotacaoDAO;
    private AnotacaoService $anotacaoService;

    public function __construct() {
        $this->anotacaoDAO = new AnotacaoDAO();
        $this->anotacaoService = new AnotacaoService();
    }

    public function listar() {
        return $this->anotacaoDAO->list();
    }

    public function buscar(int $id) {
        return $this->anotacaoDAO->findById($id);
    }

    public function inserir(Anotacao $anotacao, array $arquivos) {
        //Validar os dados
        $erros = $this->anotacaoService->validar($anotacao);

        //Salvar as imagens
        if(empty($erros)) {
            $upload = ImagemUtil::salvarMultiplas($arquivos);

            if(! empty($upload['erros'])) {
                $erros = $upload['erros'];
            } else {
                $anotacao->setImagens($upload['caminhos']);

                //Salvar a anotação na sessão
                $erroDAO = $this->anotacaoDAO->insert($anotacao);
                if($erroDAO) {
                    ImagemUtil::excluirCaminhos($upload['caminhos']);
                    array_push($erros, $erroDAO);
                }
            }
        }

        return $erros;
    }

    public function alterar(Anotacao $anotacao, array $arquivosNovos, array $removerImagens) {
        $atual = $this->anotacaoDAO->findById($anotacao->getId());
        $erros = array();

        if(! $atual) {
            array_push($erros, "Anotação não encontrada!");
            return $erros;
        }

        //Validar os dados
        $erros = $this->anotacaoService->validar($anotacao);

        if(empty($erros)) {
            $imagensMantidas = array();
            $imagensRemovidas = array();

            //Separar imagens mantidas e imagens removidas
            foreach($atual->getImagens() as $imagem) {
                if(in_array($imagem, $removerImagens))
                    array_push($imagensRemovidas, $imagem);
                else
                    array_push($imagensMantidas, $imagem);
            }

            //Salvar imagens novas
            $upload = ImagemUtil::salvarMultiplas($arquivosNovos);

            if(! empty($upload['erros'])) {
                $erros = $upload['erros'];
            } else {
                foreach($upload['caminhos'] as $caminho)
                    array_push($imagensMantidas, $caminho);

                $anotacao->setImagens($imagensMantidas);

                //Alterar a anotação na sessão
                $erroDAO = $this->anotacaoDAO->update($anotacao);
                if($erroDAO) {
                    ImagemUtil::excluirCaminhos($upload['caminhos']);
                    array_push($erros, $erroDAO);
                } else {
                    ImagemUtil::excluirCaminhos($imagensRemovidas);
                }
            }
        }

        return $erros;
    }

    public function excluir(int $id) {
        $erros = array();
        $anotacao = $this->anotacaoDAO->findById($id);

        if(! $anotacao) {
            array_push($erros, "Anotação não encontrada!");
            return $erros;
        }

        $erroDAO = $this->anotacaoDAO->delete($id);

        if($erroDAO)
            array_push($erros, $erroDAO);
        else
            ImagemUtil::excluirCaminhos($anotacao->getImagens());

        return $erros;
    }
}
