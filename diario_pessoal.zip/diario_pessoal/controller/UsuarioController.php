<?php

require_once(__DIR__ . "/../dao/UsuarioDAO.php");
require_once(__DIR__ . "/../service/UsuarioService.php");
require_once(__DIR__ . "/../util/ImagemUtil.php");

class UsuarioController {

    private UsuarioDAO $usuarioDAO;
    private UsuarioService $usuarioService;

    public function __construct() {
        $this->usuarioDAO = new UsuarioDAO();
        $this->usuarioService = new UsuarioService();
    }

    public function listar() {
        return $this->usuarioDAO->list();
    }

    public function buscar(string $login) {
        return $this->usuarioDAO->findByLogin($login);
    }

    public function atual() {
        return $this->usuarioDAO->getUsuarioAtivo();
    }

    public function cadastrar(Usuario $usuario, ?string $confirmacao) {
        //Validar os dados
        $erros = $this->usuarioService->validar($usuario, $confirmacao);

        //Verificar se o login já existe
        if($usuario->getLogin() && $this->usuarioDAO->findByLogin($usuario->getLogin()))
            array_push($erros, "Este login já está em uso!");

        //Salvar o perfil na sessão
        if(empty($erros)) {
            $usuario->setTipo("usuario");
            $usuario->setAnotacoes(array());

            $erroDAO = $this->usuarioDAO->insert($usuario);
            if($erroDAO)
                array_push($erros, $erroDAO);
        }

        return $erros;
    }

    public function excluirAtual() {
        $usuario = $this->usuarioDAO->getUsuarioAtivo();
        $erros = $this->usuarioService->validarExclusao($usuario);

        if(empty($erros)) {
            //Remover as imagens do perfil
            $dadosUsuario = array(
                'anotacoes' => $usuario->getAnotacoes()
            );
            ImagemUtil::limparImagensDosUsuarios(array($dadosUsuario));

            $erroDAO = $this->usuarioDAO->delete($usuario->getLogin());
            if($erroDAO)
                array_push($erros, $erroDAO);
        }

        return $erros;
    }
}
