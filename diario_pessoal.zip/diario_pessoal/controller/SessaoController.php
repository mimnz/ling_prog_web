<?php

require_once(__DIR__ . "/../dao/SessaoDAO.php");
require_once(__DIR__ . "/../dao/UsuarioDAO.php");
require_once(__DIR__ . "/../service/SessaoService.php");
require_once(__DIR__ . "/../util/ImagemUtil.php");

class SessaoController {

    private SessaoDAO $sessaoDAO;
    private UsuarioDAO $usuarioDAO;
    private SessaoService $sessaoService;

    public function __construct() {
        $this->sessaoDAO = new SessaoDAO();
        $this->usuarioDAO = new UsuarioDAO();
        $this->sessaoService = new SessaoService();
    }

    public function existe(): bool {
        return $this->sessaoDAO->existe();
    }

    public function exibir() {
        return $this->sessaoDAO->exibir();
    }

    public function criar(?string $senha, ?string $confirmacao) {
        $erros = array();

        if($this->sessaoDAO->existe()) {
            array_push($erros, "O diário já foi iniciado nesta sessão!");
            return $erros;
        }

        //Validar os dados
        $erros = $this->sessaoService->validarCriacao($senha, $confirmacao);

        //Criar a estrutura na sessão
        if(empty($erros)) {
            $erroDAO = $this->sessaoDAO->criarEstrutura($senha);
            if($erroDAO)
                array_push($erros, $erroDAO);
        }

        return $erros;
    }

    public function destruir() {
        $usuario = $this->usuarioDAO->getUsuarioAtivo();
        $erros = $this->sessaoService->validarDestruicao($usuario);

        if(empty($erros)) {
            $dados = $this->sessaoDAO->exibir();

            if($dados && isset($dados['usuarios']))
                ImagemUtil::limparImagensDosUsuarios($dados['usuarios']);

            $this->sessaoDAO->destruir();
        }

        return $erros;
    }
}
