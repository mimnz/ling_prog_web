<?php

require_once(__DIR__ . "/../dao/UsuarioDAO.php");
require_once(__DIR__ . "/../service/AuthService.php");

class AuthController {

    private UsuarioDAO $usuarioDAO;
    private AuthService $authService;

    public function __construct() {
        $this->usuarioDAO = new UsuarioDAO();
        $this->authService = new AuthService();
    }

    public function entrar(?string $login, ?string $senha) {
        //Validar os dados do formulário
        $erros = $this->authService->validar($login, $senha);

        //Validar login e senha na sessão
        if(empty($erros)) {
            $usuario = $this->usuarioDAO->findByLogin($login);

            if($usuario && $usuario->getSenha() == $senha) {
                $erroDAO = $this->usuarioDAO->setUsuarioAtivo($login);
                if($erroDAO)
                    array_push($erros, $erroDAO);
            } else {
                array_push($erros, "Login ou senha inválidos!");
            }
        }

        return $erros;
    }

    public function sair() {
        $this->usuarioDAO->clearUsuarioAtivo();
    }

    public function usuarioAtual(): ?Usuario {
        return $this->usuarioDAO->getUsuarioAtivo();
    }

    public function estaAutenticado(): bool {
        if($this->usuarioAtual())
            return true;

        return false;
    }

    public function ehAdmin(): bool {
        $usuario = $this->usuarioAtual();

        if($usuario && $usuario->isAdmin())
            return true;

        return false;
    }
}
