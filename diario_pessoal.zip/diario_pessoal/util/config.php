<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

define("BASE_URL", "/diario_pessoal");

define("PROJECT_ROOT", realpath(__DIR__ . "/.."));

if(session_status() != PHP_SESSION_ACTIVE)
    session_start();
