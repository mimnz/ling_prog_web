<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configuração de acesso
//Altere caso a pasta do projeto tenha outro nome no htdocs
//Exemplo: /diario_pessoal

define("BASE_URL", "/diario_pessoal");

//Caminho físico do projeto, usado para salvar e remover imagens

define("PROJECT_ROOT", realpath(__DIR__ . "/.."));

//Iniciar a sessão
if(session_status() != PHP_SESSION_ACTIVE)
    session_start();
