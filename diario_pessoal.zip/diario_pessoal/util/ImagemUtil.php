<?php

class ImagemUtil {

    public static function salvarMultiplas(array $arquivos): array {
        $caminhos = array();
        $erros = array();

        if(! isset($arquivos['name']) || ! is_array($arquivos['name']))
            return array('caminhos' => $caminhos, 'erros' => $erros);

        $pastaRelativa = "assets/img/uploads/";
        $pastaAbsoluta = PROJECT_ROOT . "/" . $pastaRelativa;

        for($i = 0; $i < count($arquivos['name']); $i++) {
            $nomeOriginal = $arquivos['name'][$i];
            $erroUpload = $arquivos['error'][$i];

            if($erroUpload == UPLOAD_ERR_NO_FILE)
                continue;

            if($erroUpload != UPLOAD_ERR_OK) {
                array_push($erros, "Erro ao enviar uma das imagens.");
                continue;
            }

            $extensao = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
            $extensoesPermitidas = array('jpg', 'jpeg', 'png', 'webp');

            if(! in_array($extensao, $extensoesPermitidas)) {
                array_push($erros, "Use somente imagens JPG, JPEG, PNG ou WEBP.");
                continue;
            }

            if(! is_dir($pastaAbsoluta))
                mkdir($pastaAbsoluta, 0777, true);

            $nomeArquivo = uniqid() . "_" . $i . "." . $extensao;
            $destino = $pastaAbsoluta . $nomeArquivo;

            if(move_uploaded_file($arquivos['tmp_name'][$i], $destino))
                array_push($caminhos, $pastaRelativa . $nomeArquivo);
            else
                array_push($erros, "Erro ao salvar uma das imagens.");
        }

        return array('caminhos' => $caminhos, 'erros' => $erros);
    }

    public static function excluirCaminhos(array $caminhos) {
        foreach($caminhos as $caminho) {
            $arquivo = PROJECT_ROOT . "/" . $caminho;

            if(file_exists($arquivo))
                unlink($arquivo);
        }
    }

    public static function limparImagensDosUsuarios(array $usuarios) {
        foreach($usuarios as $usuario) {
            if(isset($usuario['anotacoes'])) {
                foreach($usuario['anotacoes'] as $anotacao) {
                    if(isset($anotacao['imagens']))
                        self::excluirCaminhos($anotacao['imagens']);
                }
            }
        }
    }
}
