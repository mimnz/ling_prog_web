<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");

if(! isset($tituloPagina))
    $tituloPagina = "FlyNote";

$authHeader = new AuthController();
$usuarioHeader = $authHeader->usuarioAtual();
$sessaoExisteHeader = isset($_SESSION['diario']);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $tituloPagina ?> | FlyNote</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php require_once(__DIR__ . "/sidebar.php"); ?>

<main class="app-main">
