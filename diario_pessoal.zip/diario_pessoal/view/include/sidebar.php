<header class="topo">
    <a class="marca" href="<?= BASE_URL ?>/index.php">
        <span class="marca-simbolo">Fly</span>
        <span><strong>FlyNote</strong><small>diário pessoal</small></span>
    </a>

    <nav class="navegacao">
        <?php if($usuarioHeader): ?>
            <a href="<?= BASE_URL ?>/view/diario/timeline.php">Anotações</a>

            <?php if($usuarioHeader->isAdmin()): ?>
                <a href="<?= BASE_URL ?>/view/sessao/exibir.php">Sessão</a>
            <?php endif; ?>

            <span class="menu-separador"></span>
            <span class="usuario-menu">@<?= $usuarioHeader->getLogin() ?></span>
            <a href="<?= BASE_URL ?>/view/auth/logout.php">Sair</a>

        <?php elseif($sessaoExisteHeader): ?>
            <a href="<?= BASE_URL ?>/view/auth/login.php">Entrar</a>
            <a href="<?= BASE_URL ?>/view/auth/cadastro.php">Criar perfil</a>

        <?php else: ?>
            <a href="<?= BASE_URL ?>/index.php">Início</a>
        <?php endif; ?>
    </nav>
</header>
