<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");

$authCont = new AuthController();
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

//Receber o ID da anotação a ser excluída
if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $anotacaoCont = new AnotacaoController();
    $erros = $anotacaoCont->excluir($id);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/diario/timeline.php");
        exit;
    } else {
        echo implode("<br>", $erros);
        echo "<br><a href='timeline.php'>Voltar</a>";
    }
} else {
    echo "ID da anotação não informado!<br>";
    echo "<a href='timeline.php'>Voltar</a>";
}
