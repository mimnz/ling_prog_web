<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");

$authCont = new AuthController();
$usuario = $authCont->usuarioAtual();

if(! $usuario) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$anotacaoCont = new AnotacaoController();
$anotacoes = $anotacaoCont->listar();

$tituloPagina = "Minhas anotações";
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div class="pagina-topo-flex">
        <div>
            <p class="sobretitulo">Diário de <?= $usuario->getNome() ?></p>
            <h1>Minhas anotações</h1>
        </div>
        <a class="btn btn-primary" href="<?= BASE_URL ?>/view/diario/inserir.php">Nova anotação</a>
    </div>
</header>

<div class="page">
    <?php if(empty($anotacoes)): ?>
        <div class="empty-state panel">
            <h3>Nenhuma anotação cadastrada.</h3>
            <p>Crie a primeira anotação para começar.</p>
            <a class="btn btn-primary" href="<?= BASE_URL ?>/view/diario/inserir.php">Criar anotação</a>
        </div>

    <?php else: ?>
        <div class="timeline">
            <?php foreach($anotacoes as $anotacao): ?>
                <article class="timeline-item">
                    <div class="timeline-date">
                        <strong><?= date("d", strtotime($anotacao->getData())) ?></strong>
                        <span><?= date("m/Y", strtotime($anotacao->getData())) ?></span>
                    </div>

                    <div class="note-card">
                        <div class="note-card-head">
                            <h3><?= $anotacao->getTitulo() ?></h3>

                            <div class="note-actions">
                                <a href="<?= BASE_URL ?>/view/diario/visualizar.php?id=<?= $anotacao->getId() ?>">Abrir</a>
                                <a href="<?= BASE_URL ?>/view/diario/alterar.php?id=<?= $anotacao->getId() ?>">Editar</a>
                                <a class="note-delete"
                                   href="<?= BASE_URL ?>/view/diario/excluir.php?id=<?= $anotacao->getId() ?>"
                                   onclick="return confirm('Excluir esta anotação?');">Excluir</a>
                            </div>
                        </div>

                        <p class="note-preview">
                            <?= substr($anotacao->getTexto(), 0, 220) ?>
                            <?= strlen($anotacao->getTexto()) > 220 ? "..." : "" ?>
                        </p>

                        <?php if(! empty($anotacao->getImagens())): ?>
                            <div class="thumb-row">
                                <?php
                                $limite = count($anotacao->getImagens());
                                if($limite > 4)
                                    $limite = 4;

                                for($i = 0; $i < $limite; $i++):
                                    $imagem = $anotacao->getImagens()[$i];
                                ?>
                                    <img src="<?= BASE_URL ?>/<?= $imagem ?>" alt="Imagem da anotação">
                                <?php endfor; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
