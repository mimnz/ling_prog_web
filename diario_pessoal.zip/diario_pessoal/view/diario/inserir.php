<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");
require_once(__DIR__ . "/../../model/Anotacao.php");

$authCont = new AuthController();
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$msgErro = "";
$anotacao = new Anotacao();
$anotacao->setId(0);
$anotacao->setData(date("Y-m-d"));
$anotacao->setImagens(array());

//Verificar se o formulário foi enviado
if(isset($_POST['titulo'])) {
    $data = $_POST['data'];
    $titulo = trim($_POST['titulo']) ? trim($_POST['titulo']) : NULL;
    $texto = trim($_POST['texto']) ? trim($_POST['texto']) : NULL;

    //Montar o objeto Anotacao
    $anotacao->setData($data);
    $anotacao->setTitulo($titulo);
    $anotacao->setTexto($texto);

    //Validar e salvar na sessão
    $arquivos = array();
    if(isset($_FILES['imagens']))
        $arquivos = $_FILES['imagens'];

    $anotacaoCont = new AnotacaoController();
    $erros = $anotacaoCont->inserir($anotacao, $arquivos);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/diario/timeline.php");
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }
}

$editando = false;
$msgBotao = "Salvar anotação";
$tituloPagina = "Nova anotação";
require_once(__DIR__ . "/form.php");
