<?php require_once(__DIR__ . "/../include/header.php"); ?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo"><?= $editando ? "Editar anotação" : "Nova anotação" ?></p>
        <h1><?= $editando ? "Editar anotação" : "Nova anotação" ?></h1>
    </div>
</header>

<div class="page editor-page">
    <?php if($msgErro): ?>
        <div class="alerta erro"><?= $msgErro ?></div>
    <?php endif; ?>

    <div class="editor-shell">
        <form method="POST" enctype="multipart/form-data" class="editor-form">

            <?php if($editando): ?>
                <input type="hidden" name="id" value="<?= $anotacao->getId() ?>">
            <?php endif; ?>

            <label class="campo compact-field">
                <span>Data</span>
                <input type="date" name="data" value="<?= $anotacao->getData() ?>" required>
            </label>

            <label class="campo">
                <span>Título</span>
                <input class="title-input" type="text" name="titulo" maxlength="120"
                       value="<?= $anotacao->getTitulo() ?>" required>
            </label>

            <label class="campo">
                <span>Anotação</span>
                <textarea class="note-textarea" name="texto" required><?= $anotacao->getTexto() ?></textarea>
            </label>

            <?php if($editando && ! empty($anotacao->getImagens())): ?>
                <div class="existing-images">
                    <span class="field-title">Imagens atuais</span>
                    <div class="image-check-grid">
                        <?php foreach($anotacao->getImagens() as $imagem): ?>
                            <label class="image-check">
                                <img src="<?= BASE_URL ?>/<?= $imagem ?>" alt="Imagem anexada">
                                <span>
                                    <input type="checkbox" name="remover_imagens[]" value="<?= $imagem ?>">
                                    remover
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <label class="upload-box">
                <input type="file" name="imagens[]" accept="image/jpeg,image/png,image/webp" multiple>
                <strong>Anexar imagens</strong>
                <small>Opcional · JPG, JPEG, PNG ou WEBP</small>
            </label>

            <div class="editor-actions">
                <a class="btn btn-secondary" href="<?= BASE_URL ?>/view/diario/timeline.php">Cancelar</a>
                <button class="btn btn-primary" type="submit"><?= $msgBotao ?></button>
            </div>
        </form>
    </div>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
