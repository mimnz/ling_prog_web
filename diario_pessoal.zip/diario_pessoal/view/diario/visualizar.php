<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");

$authCont = new AuthController();
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$id = 0;
if(isset($_GET['id']))
    $id = $_GET['id'];

$anotacaoCont = new AnotacaoController();
$anotacao = $anotacaoCont->buscar($id);

if(! $anotacao) {
    echo "ID da anotação inválido!<br>";
    echo "<a href='timeline.php'>Voltar</a>";
    exit;
}

$tituloPagina = $anotacao->getTitulo();
require_once(__DIR__ . "/../include/header.php");
?>

<div class="page note-detail-page">
    <a class="back-link" href="<?= BASE_URL ?>/view/diario/timeline.php">← Voltar para as anotações</a>

    <article class="note-detail">
        <header class="note-detail-head">
            <div>
                <h1><?= $anotacao->getTitulo() ?></h1>
                <time><?= $anotacao->getDataFormatada() ?></time>
            </div>

            <div class="detail-actions">
                <a class="btn btn-secondary" href="<?= BASE_URL ?>/view/diario/alterar.php?id=<?= $id ?>">Editar</a>
                <a class="btn btn-danger-ghost"
                   href="<?= BASE_URL ?>/view/diario/excluir.php?id=<?= $id ?>"
                   onclick="return confirm('Excluir esta anotação?');">Excluir</a>
            </div>
        </header>

        <div class="note-body"><?= nl2br($anotacao->getTexto()) ?></div>

        <?php if(! empty($anotacao->getImagens())): ?>
            <div class="gallery">
                <?php foreach($anotacao->getImagens() as $imagem): ?>
                    <a href="<?= BASE_URL ?>/<?= $imagem ?>" target="_blank">
                        <img src="<?= BASE_URL ?>/<?= $imagem ?>" alt="Imagem anexada">
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
