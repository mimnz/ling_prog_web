<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");

$authCont = new AuthController();
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$msgErro = "";
$anotacaoCont = new AnotacaoController();

//Verificar se o formulário já foi enviado
if(isset($_POST['titulo'])) {
    $id = $_POST['id'];
    $data = $_POST['data'];
    $titulo = trim($_POST['titulo']) ? trim($_POST['titulo']) : NULL;
    $texto = trim($_POST['texto']) ? trim($_POST['texto']) : NULL;

    $anotacao = $anotacaoCont->buscar($id);

    if(! $anotacao) {
        echo "ID da anotação inválido!<br>";
        echo "<a href='timeline.php'>Voltar</a>";
        exit;
    }

    $anotacao->setData($data);
    $anotacao->setTitulo($titulo);
    $anotacao->setTexto($texto);

    $removerImagens = array();
    if(isset($_POST['remover_imagens']))
        $removerImagens = $_POST['remover_imagens'];

    $arquivos = array();
    if(isset($_FILES['imagens']))
        $arquivos = $_FILES['imagens'];

    $erros = $anotacaoCont->alterar($anotacao, $arquivos, $removerImagens);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/diario/visualizar.php?id=" . $id);
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }

} else {
    //Carregar a anotação que será alterada
    $id = 0;
    if(isset($_GET['id']))
        $id = $_GET['id'];

    $anotacao = $anotacaoCont->buscar($id);

    if(! $anotacao) {
        echo "ID da anotação inválido!<br>";
        echo "<a href='timeline.php'>Voltar</a>";
        exit;
    }
}

$editando = true;
$msgBotao = "Salvar alterações";
$tituloPagina = "Editar anotação";
require_once(__DIR__ . "/form.php");
