<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");

$sessaoCont = new SessaoController();
$erros = $sessaoCont->destruir();

if(empty($erros)) {
    header("location: " . BASE_URL . "/view/sessao/exibir.php");
    exit;
} else {
    echo implode("<br>", $erros);
    echo "<br><a href='exibir.php'>Voltar</a>";
}
