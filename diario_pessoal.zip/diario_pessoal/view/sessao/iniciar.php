<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");

$sessaoCont = new SessaoController();
$msgErro = "";

if(isset($_POST['senha'])) {
    $senha = $_POST['senha'];
    $confirmacao = $_POST['confirmacao'];

    $erros = $sessaoCont->criar($senha, $confirmacao);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/auth/login.php");
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }
}

$tituloPagina = "Criar sessão";
require_once(__DIR__ . "/../include/header.php");
?>

<div class="page narrow">
    <div class="page-head">
        <h1>Criar valor na sessão</h1>
        <p>Cria a chave <code>$_SESSION['diario']</code>.</p>
    </div>

    <?php if($sessaoCont->existe()): ?>
        <div class="alerta erro">O diário já foi iniciado nesta sessão.</div>
    <?php else: ?>
        <?php if($msgErro): ?>
            <div class="alerta erro"><?= $msgErro ?></div>
        <?php endif; ?>

        <form method="POST" class="panel formulario" style="padding:20px;">
            <label class="campo">
                <span>Senha do administrador</span>
                <input type="password" name="senha" required>
            </label>

            <label class="campo">
                <span>Confirmar senha</span>
                <input type="password" name="confirmacao" required>
            </label>

            <button class="btn btn-primary" type="submit">Criar sessão</button>
        </form>
    <?php endif; ?>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
