<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");
require_once(__DIR__ . "/../../controller/AuthController.php");

$sessaoCont = new SessaoController();
$dados = $sessaoCont->exibir();

$authCont = new AuthController();
$usuario = $authCont->usuarioAtual();

$tituloPagina = "Sessão";
require_once(__DIR__ . "/../include/header.php");
?>

<div class="page session-page">
    <?php if(! $dados): ?>
        <div class="session-empty">
            <h1>Sessão não existe!</h1>
            <a class="btn btn-primary" href="<?= BASE_URL ?>/index.php">Iniciar novamente</a>
        </div>

    <?php elseif(! $usuario || ! $usuario->isAdmin()): ?>
        <div class="session-empty">
            <h1>Área do administrador</h1>
            <p>Somente o perfil <strong>adm</strong> pode visualizar ou destruir a sessão completa.</p>
            <a class="btn btn-primary" href="<?= BASE_URL ?>/view/auth/login.php">Entrar como administrador</a>
        </div>

    <?php else: ?>
        <div class="page-head dashboard-head">
            <div>
                <p class="sobretitulo">Administração</p>
                <h1>Sessão atual</h1>
            </div>

            <a class="btn btn-danger"
               href="<?= BASE_URL ?>/view/sessao/destruir.php"
               onclick="return confirm('Destruir a sessão inteira? Todos os perfis e anotações serão apagados.');">
                Destruir sessão
            </a>
        </div>

        <section class="panel session-code">
            <div class="section-head">
                <h2>$_SESSION['diario']</h2>
            </div>
            <pre><?php print_r($dados); ?></pre>
        </section>
    <?php endif; ?>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
