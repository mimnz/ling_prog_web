<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");

$sessaoCont = new SessaoController();
$msgErro = "";

//Verificar se o formulário foi enviado
if(isset($_POST['senha'])) {
    $senha = $_POST['senha'];
    $confirmacao = $_POST['confirmacao'];

    $erros = $sessaoCont->criar($senha, $confirmacao);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/auth/login.php");
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }
}

$tituloPagina = "Iniciar diário";
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Diário pessoal</p>
        <h1>FlyNote</h1>
        <p>Anotações temporárias usando sessão PHP.</p>
    </div>
</header>

<section class="secao">
    <div class="page-head">
        <h1>Iniciar sessão</h1>
        <p>Defina a senha do administrador. O login inicial será <strong>adm</strong>.</p>
    </div>

    <?php if($msgErro): ?>
        <div class="alerta erro"><?= $msgErro ?></div>
    <?php endif; ?>

    <form method="POST" class="auth-card formulario">
        <label class="campo">
            <span>Senha do administrador</span>
            <input type="password" name="senha" required>
        </label>

        <label class="campo">
            <span>Confirmar senha</span>
            <input type="password" name="confirmacao" required>
        </label>

        <div>
            <button class="btn btn-primary" type="submit">Iniciar diário</button>
        </div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
