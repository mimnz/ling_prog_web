<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/UsuarioController.php");

$authCont = new AuthController();
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$usuarioCont = new UsuarioController();
$erros = $usuarioCont->excluirAtual();

if(empty($erros)) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
} else {
    echo implode("<br>", $erros);
    echo "<br><a href='perfil.php'>Voltar</a>";
}
