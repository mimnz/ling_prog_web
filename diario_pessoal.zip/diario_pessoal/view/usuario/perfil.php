<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AnotacaoController.php");

$authCont = new AuthController();
$usuario = $authCont->usuarioAtual();

if(! $usuario) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

$anotacaoCont = new AnotacaoController();
$anotacoes = $anotacaoCont->listar();

$tituloPagina = "Meu perfil";
require_once(__DIR__ . "/../include/header.php");
?>

<div class="page narrow">
    <div class="page-head">
        <h1>Minha conta</h1>
    </div>

    <section class="panel profile-card">
        <div class="profile-avatar"><?= strtoupper(substr($usuario->getNome(), 0, 1)) ?></div>
        <div class="profile-main">
            <h2><?= $usuario->getNome() ?></h2>
            <p>@<?= $usuario->getLogin() ?></p>
            <span class="badge"><?= $usuario->isAdmin() ? "Administrador" : "Usuário" ?></span>
            <span class="badge muted"><?= count($anotacoes) ?> anotações</span>
        </div>
    </section>

    <section class="panel settings-list">
        <div class="setting-row">
            <div>
                <strong>Sair da conta</strong>
                <p>As anotações continuam armazenadas na sessão.</p>
            </div>
            <a class="btn btn-secondary" href="<?= BASE_URL ?>/view/auth/logout.php">Sair</a>
        </div>

        <?php if(! $usuario->isAdmin()): ?>
            <div class="setting-row danger-row">
                <div>
                    <strong>Excluir meu perfil</strong>
                    <p>Remove este perfil e suas anotações.</p>
                </div>
                <a class="btn btn-danger-ghost"
                   href="<?= BASE_URL ?>/view/usuario/excluir.php"
                   onclick="return confirm('Excluir seu perfil e todas as suas anotações?');">Excluir perfil</a>
            </div>
        <?php else: ?>
            <div class="setting-row">
                <div>
                    <strong>Administração da sessão</strong>
                    <p>Visualizar ou destruir a sessão completa.</p>
                </div>
                <a class="btn btn-secondary" href="<?= BASE_URL ?>/view/sessao/exibir.php">Abrir sessão</a>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
