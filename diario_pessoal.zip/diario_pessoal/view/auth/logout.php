<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/AuthController.php");

$authCont = new AuthController();
$authCont->sair();

header("location: " . BASE_URL . "/view/auth/login.php");
exit;
