<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");
require_once(__DIR__ . "/../../controller/UsuarioController.php");
require_once(__DIR__ . "/../../model/Usuario.php");

$sessaoCont = new SessaoController();
if(! $sessaoCont->existe()) {
    header("location: " . BASE_URL . "/index.php");
    exit;
}

$msgErro = "";
$usuario = new Usuario();

//Verificar se o formulário foi enviado
if(isset($_POST['nome'])) {
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $login = trim($_POST['login']) ? strtolower(trim($_POST['login'])) : NULL;
    $senha = trim($_POST['senha']) ? trim($_POST['senha']) : NULL;
    $confirmacao = trim($_POST['confirmacao']) ? trim($_POST['confirmacao']) : NULL;

    //Criar o objeto Usuario
    $usuario->setNome($nome);
    $usuario->setLogin($login);
    $usuario->setSenha($senha);

    //Validar e salvar na sessão
    $usuarioCont = new UsuarioController();
    $erros = $usuarioCont->cadastrar($usuario, $confirmacao);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/auth/login.php");
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }
}

$tituloPagina = "Criar perfil";
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Perfis da sessão</p>
        <h1>Criar perfil</h1>
        <p>O perfil ficará disponível somente enquanto esta sessão PHP existir.</p>
    </div>
</header>

<section class="auth-layout compact">
    <div class="auth-card">
        <?php if($msgErro): ?>
            <div class="alerta erro"><?= $msgErro ?></div>
        <?php endif; ?>

        <form method="POST" class="formulario">
            <label class="campo">
                <span>Nome</span>
                <input type="text" name="nome" value="<?= $usuario->getNome() ?>" required>
            </label>

            <label class="campo">
                <span>Login</span>
                <input type="text" name="login" value="<?= $usuario->getLogin() ?>" required>
            </label>

            <div class="form-row">
                <label class="campo">
                    <span>Senha</span>
                    <input type="password" name="senha" required>
                </label>

                <label class="campo">
                    <span>Confirmar senha</span>
                    <input type="password" name="confirmacao" required>
                </label>
            </div>

            <div>
                <button class="btn btn-primary" type="submit">Criar perfil</button>
            </div>
        </form>

        <div class="auth-links">
            <span>Já possui perfil?</span>
            <a href="<?= BASE_URL ?>/view/auth/login.php">Entrar</a>
        </div>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
