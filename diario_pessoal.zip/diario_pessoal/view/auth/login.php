<?php

require_once(__DIR__ . "/../../util/config.php");
require_once(__DIR__ . "/../../controller/SessaoController.php");
require_once(__DIR__ . "/../../controller/AuthController.php");

$sessaoCont = new SessaoController();
if(! $sessaoCont->existe()) {
    header("location: " . BASE_URL . "/index.php");
    exit;
}

$authCont = new AuthController();
if($authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/diario/timeline.php");
    exit;
}

$msgErro = "";
$login = "";

//Rotina para logar
if(isset($_POST['login'])) {
    $login = trim($_POST['login']) ? trim($_POST['login']) : NULL;
    $senha = trim($_POST['senha']) ? trim($_POST['senha']) : NULL;

    $erros = $authCont->entrar($login, $senha);

    if(empty($erros)) {
        header("location: " . BASE_URL . "/view/diario/timeline.php");
        exit;
    } else {
        $msgErro = implode("<br>", $erros);
    }
}

$tituloPagina = "Entrar";
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Acesso</p>
        <h1>Entrar</h1>
        <p>Entre em um perfil existente nesta sessão.</p>
    </div>
</header>

<section class="auth-layout compact">
    <div class="auth-card">
        <?php if($msgErro): ?>
            <div class="alerta erro"><?= $msgErro ?></div>
        <?php endif; ?>

        <form method="POST" class="formulario">
            <label class="campo">
                <span>Login</span>
                <input type="text" name="login" value="<?= $login ?>" required>
            </label>

            <label class="campo">
                <span>Senha</span>
                <input type="password" name="senha" required>
            </label>

            <div>
                <button class="btn btn-primary" type="submit">Entrar</button>
            </div>
        </form>

        <div class="auth-links">
            <span>Não possui perfil?</span>
            <a href="<?= BASE_URL ?>/view/auth/cadastro.php">Criar perfil</a>
        </div>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
