# FlyNote

Projeto escolar em PHP para a atividade de Sessões.

## Como funciona

- Os dados ficam em `$_SESSION['diario']`.
- Não utiliza banco de dados nem localStorage.
- Podem existir vários perfis temporários dentro da mesma sessão.
- O login `adm` é criado quando a sessão é iniciada.
- Apenas o administrador pode destruir a sessão inteira.
- Cada perfil possui suas próprias anotações.
- Uma anotação pode ser criada, visualizada, alterada e excluída.
- As imagens são salvas em `assets/img/uploads/`. A pasta é criada automaticamente no primeiro upload.

## Estrutura usada

O projeto mantém a separação:

- `controller`
- `dao`
- `service`
- `model`
- `view`

O DAO acessa os arrays guardados em `$_SESSION` no lugar de um banco de dados.

## BASE_URL

Em `util/config.php` está configurado:

```php
define("BASE_URL", "/diario_pessoal");
```

Se a pasta tiver outro nome dentro do `htdocs`, altere esse valor.

Exemplo: se o projeto estiver em `htdocs/flynote`, use:

```php
define("BASE_URL", "/flynote");
```

## Observação sobre as imagens

`ImagemUtil.php` ficou separado porque upload de arquivos exige algumas funções próprias do PHP. A implementação foi mantida simples: `pathinfo()`, `in_array()`, `mkdir()`, `uniqid()`, `move_uploaded_file()`, `file_exists()` e `unlink()`.
