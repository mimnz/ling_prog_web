<?php

require_once(__DIR__ . "/../model/Usuario.php");

class UsuarioService {

    public function validar(Usuario $usuario, ?string $confirmacao) {
        $erros = array();

        if(! $usuario->getNome())
            array_push($erros, "Informe o nome!");

        if(! $usuario->getLogin())
            array_push($erros, "Informe o login!");

        if($usuario->getLogin() == "adm")
            array_push($erros, "O login adm é reservado ao administrador!");

        if(! $usuario->getSenha())
            array_push($erros, "Informe a senha!");

        if(! $confirmacao)
            array_push($erros, "Confirme a senha!");

        if($usuario->getSenha() && $confirmacao && $usuario->getSenha() != $confirmacao)
            array_push($erros, "As senhas não coincidem!");

        return $erros;
    }

    public function validarExclusao(?Usuario $usuario) {
        $erros = array();

        if(! $usuario)
            array_push($erros, "Perfil não encontrado!");
        else if($usuario->isAdmin())
            array_push($erros, "O perfil administrador não pode ser excluído!");

        return $erros;
    }
}
