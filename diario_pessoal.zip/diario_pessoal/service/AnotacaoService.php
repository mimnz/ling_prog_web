<?php

require_once(__DIR__ . "/../model/Anotacao.php");

class AnotacaoService {

    public function validar(Anotacao $anotacao) {
        $erros = array();

        if(! $anotacao->getData())
            array_push($erros, "Informe a data!");

        if(! $anotacao->getTitulo())
            array_push($erros, "Informe o título!");

        if(! $anotacao->getTexto())
            array_push($erros, "Informe a anotação!");

        return $erros;
    }
}
