<?php

require_once(__DIR__ . "/../model/Usuario.php");

class SessaoService {

    public function validarCriacao(?string $senha, ?string $confirmacao) {
        $erros = array();

        if(! $senha)
            array_push($erros, "Informe a senha do administrador!");

        if(! $confirmacao)
            array_push($erros, "Confirme a senha do administrador!");

        if($senha && $confirmacao && $senha != $confirmacao)
            array_push($erros, "As senhas não coincidem!");

        return $erros;
    }

    public function validarDestruicao(?Usuario $usuario) {
        $erros = array();

        if(! $usuario)
            array_push($erros, "Faça login para acessar esta ação!");
        else if(! $usuario->isAdmin())
            array_push($erros, "Apenas o administrador pode destruir a sessão!");

        return $erros;
    }
}
