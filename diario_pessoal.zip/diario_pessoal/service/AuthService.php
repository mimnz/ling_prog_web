<?php

class AuthService {

    public function validar(?string $login, ?string $senha) {
        $erros = array();

        if(! $login)
            array_push($erros, "Informe o login!");

        if(! $senha)
            array_push($erros, "Informe a senha!");

        return $erros;
    }
}
