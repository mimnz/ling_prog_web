<?php

require_once(__DIR__ . "/util/config.php");
require_once(__DIR__ . "/controller/SessaoController.php");
require_once(__DIR__ . "/controller/AuthController.php");

$sessaoCont = new SessaoController();
$authCont = new AuthController();

//Se ainda não existe a estrutura do diário, mostrar a página inicial
if(! $sessaoCont->existe()) {
    require_once(__DIR__ . "/view/home/home.php");
    exit;
}

//Se ninguém está logado, ir para o login
if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

//Usuário logado: abrir as anotações
header("location: " . BASE_URL . "/view/diario/timeline.php");
exit;
