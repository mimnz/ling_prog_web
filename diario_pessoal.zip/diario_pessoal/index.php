<?php

require_once(__DIR__ . "/util/config.php");
require_once(__DIR__ . "/controller/SessaoController.php");
require_once(__DIR__ . "/controller/AuthController.php");

$sessaoCont = new SessaoController();
$authCont = new AuthController();

if(! $sessaoCont->existe()) {
    require_once(__DIR__ . "/view/home/home.php");
    exit;
}

if(! $authCont->estaAutenticado()) {
    header("location: " . BASE_URL . "/view/auth/login.php");
    exit;
}

header("location: " . BASE_URL . "/view/diario/timeline.php");
exit;
