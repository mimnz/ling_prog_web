<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once("util/Conexao.php");
require_once("model/Aluno.php");
require_once("model/ValidadorAluno.php");

$conexao = Conexao::getConexao();
$msgErro = "";

$nome = $data_nasc = $cpf = $telefone = $modalidade = $plano = $anamnese = $objetivo = "";

if(isset($_POST['nome'])) {
    
    $aluno = new Aluno(
        $_POST['nome'],
        $_POST['data_nasc'],
        $_POST['cpf'],
        $_POST['telefone'],
        $_POST['modalidade'],
        $_POST['plano'],
        $_POST['anamnese'],
        $_POST['objetivo']
    );

    $validador = new ValidadorAluno($conexao);

    if($validador->validar($aluno)) {
        $sql = "INSERT INTO alunos (nome, data_nascimento, cpf, telefone, modalidade, plano, anamnese, objetivo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stm = $conexao->prepare($sql);
        $stm->execute([
            $aluno->getNome(),
            $aluno->getDataNasc(),
            $aluno->getCpf(),
            $aluno->getTelefone(),
            $aluno->getModalidade(),
            $aluno->getPlano(),
            $aluno->getAnamnese(),
            $aluno->getObjetivo()
        ]);

        header("location: alunos_lista.php");
        exit;
    } else {
        $msgErro = implode("<br>", $validador->getErros());
        
        $nome = $_POST['nome'];
        $data_nasc = $_POST['data_nasc'];
        $cpf = $_POST['cpf'];
        $telefone = $_POST['telefone'];
        $modalidade = $_POST['modalidade'];
        $plano = $_POST['plano'];
        $anamnese = $_POST['anamnese'];
        $objetivo = $_POST['objetivo'];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="logo.png">
    <title>Veldris - Inscrição de Alunos</title>
    <style>
        :root {
            --bg-color: #121212;
            --card-bg: rgba(30, 30, 30, 0.85);
            --primary-color: #ccff00;
            --text-color: #ffffff;
            --text-muted: #aaaaaa;
            --border-color: rgba(255, 255, 255, 0.1);
            --danger-color: #ff3333;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
            margin: 0;
            padding: 20px;
            background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('fundo.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        /* ESTRUTURA DO LADO ESQUERDO / LADO DIREITO */
        .layout-split {
            display: flex;
            max-width: 1400px;
            margin: 0 auto;
            gap: 40px;
            align-items: flex-start;
        }

        /* Coluna do Logo (Esquerda) */
        .col-logo {
            flex: 1;
            position: sticky; /* Deixa o logo fixo na tela enquanto rola o formulário */
            top: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        /* Efeito Suave no Logo da Veldris */
        .col-logo img, .logo {
            max-width: 100%;
            height: auto;
            filter: drop-shadow(0 0 15px rgba(204, 255, 0, 0.4));
            transition: transform 0.4s ease-in-out, filter 0.4s ease-in-out;
        }

        .col-logo img:hover, .logo:hover {
            transform: scale(1.08);
            filter: drop-shadow(0 0 25px rgba(204, 255, 0, 0.7)); /* Aumenta o brilho neon no hover */
        }

        /* Coluna do Conteúdo (Direita) */
        .col-content {
            flex: 2; /* Ocupa o dobro do tamanho da coluna do logo */
        }

        h1 {
            color: var(--primary-color);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 5px;
            text-shadow: 0 0 10px rgba(204, 255, 0, 0.5);
        }

        h3 {
            border-left: 4px solid var(--primary-color);
            padding-left: 10px;
            margin-top: 20px;
            margin-bottom: 25px;
            text-transform: uppercase;
            font-size: 1.2rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.8);
        }

        form {
            background-color: var(--card-bg);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }

        .form-section:hover {
            transform: scale(1.02);
        }

        .form-section {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
            transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), 
                        box-shadow 0.3s ease, 
                        border-color 0.3s ease, 
                        background-color 0.3s ease;
        }

        .form-section h4 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 1.1rem;
        }

        .grid-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 5px;
        }

        /* Animação Suave para os Campos de Digitação */
        input[type="text"], 
        input[type="date"], 
        input[type="tel"], 
        select, 
        textarea {
            background-color: rgba(45, 45, 45, 0.8);
            border: 1px solid var(--border-color);
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            font-size: 1rem;
            outline: none;
            /* Transição aplicada no transform, box-shadow e border ao mesmo tempo */
            transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), 
                        box-shadow 0.3s ease, 
                        border-color 0.3s ease, 
                        background-color 0.3s ease;
        }

        /* Quando o usuário clica para preencher o campo */
        input:focus, 
        select:focus, 
        textarea:focus {
            border-color: var(--primary-color);
            background-color: rgba(55, 55, 55, 0.95);
            box-shadow: 0 0 12px rgba(204, 255, 0, 0.4);
            transform: scale(1.02); /* Dá um leve saltinho sutil para frente */
        }

        textarea {
            resize: vertical;
            min-height: 80px;
            width: 100%;
            box-sizing: border-box;
        }

        /* Animação do Botão de Enviar (Efetivar Matrícula) */
        button {
            background-color: var(--primary-color);
            color: #000;
            border: none;
            padding: 12px 30px;
            font-size: 1rem;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            /* Controla o retorno suave do botão quando o mouse sai */
            transition: transform 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
        }

        button:hover {
            background-color: #b3df00;
            transform: scale(1.015); /* Cresce de forma imponente */
            box-shadow: 0 0 20px rgba(204, 255, 0, 0.6); /* Brilho neon intenso */
        }

        /* Efeito de clique físico no botão */
        button:active {
            transform: scale(0.99); 
        }

        .alert-error {
            background-color: rgba(255, 51, 51, 0.1);
            border: 1px solid var(--danger-color);
            color: #ff3333;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        /* Anamnese de Flutuação no Link do Topo (Ver Alunos / Nova Inscrição) */
        .btn-header {
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 1px solid var(--border-color);
            text-decoration: none;
            padding: 10px 20px;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 5px;
            transition: transform 0.3s ease, background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .btn-header:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px); /* Faz o botão flutuar levemente para cima */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .btn-header:active {
            transform: translateY(-1px);
        }

        /* Responsividade para telas de celular */
        @media (max-width: 900px) {
            .layout-split {
                flex-direction: column;
            }
            .col-logo {
                position: relative;
                top: 0;
                width: 100%;
                box-sizing: border-box;
            }
            .col-logo img {
                max-width: 200px;
            }
        }
    </style>
</head>
<body>

<div class="layout-split">
    
    <div class="col-logo">
        <img src="logo.png" class="logo" alt="Veldris Logo">
    </div>

    <div class="col-content">
        <h1>Painel de Controle</h1>
        
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h3>Nova Inscrição de Aluno</h3>
            <a href="alunos_lista.php" class="btn-header">Ver Alunos Matriculados</a>
        </div>

        <?php if(!empty($msgErro)): ?>
            <div class="alert-error"><?= $msgErro ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="form-section">
                <h4>1. Dados Pessoais e Contato</h4>
                <div class="grid-inputs">
                    <div class="form-group">
                        <label for="nome">Nome Completo</label>
                        <input type="text" name="nome" id="nome" placeholder="Nome do aluno" value="<?= htmlspecialchars($nome) ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_nasc">Data de Nascimento</label>
                        <input type="date" name="data_nasc" id="data_nasc" value="<?= $data_nasc ?>">
                    </div>
                    <div class="form-group">
                        <label for="cpf">CPF</label>
                        <input type="text" name="cpf" id="cpf" placeholder="000.000.000-00" value="<?= htmlspecialchars($cpf) ?>">
                    </div>
                    <div class="form-group">
                        <label for="telefone">Telefone / WhatsApp</label>
                        <input type="tel" name="telefone" id="telefone" placeholder="(00) 00000-0000" value="<?= htmlspecialchars($telefone) ?>">
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h4>2. Escolha do Plano e Pagamento</h4>
                <div class="grid-inputs">
                    <div class="form-group">
                        <label for="modalidade">Modalidade</label>
                        <select name="modalidade" id="modalidade">
                            <option value="">-- Selecione --</option>
                            <option value="MU" <?= $modalidade == "MU" ? "selected" : "" ?>>Musculação</option>
                            <option value="FU" <?= $modalidade == "FU" ? "selected" : "" ?>>Funcional</option>
                            <option value="AC" <?= $modalidade == "AC" ? "selected" : "" ?>>Aulas Coletivas</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="plano">Plano</label>
                        <select name="plano" id="plano">
                            <option value="">-- Selecione --</option>
                            <option value="M" <?= $plano == "M" ? "selected" : "" ?>>Mensal</option>
                            <option value="T" <?= $plano == "T" ? "selected" : "" ?>>Trimestral</option>
                            <option value="S" <?= $plano == "S" ? "selected" : "" ?>>Semestral</option>
                            <option value="A" <?= $plano == "A" ? "selected" : "" ?>>Anual</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h4>3. Anamnese e Saúde</h4>
                <div class="form-group">
                    <label for="anamnese">Histórico Médico</label>
                    <textarea name="anamnese" id="anamnese" placeholder="Ex: Hipertensão controlada..."><?= htmlspecialchars($anamnese) ?></textarea>
                </div>
            </div>

            <div class="form-section">
                <h4>4. Objetivos e Estilo de Vida</h4>
                <div class="grid-inputs">
                    <div class="form-group">
                        <label for="objetivo">Objetivo Principal</label>
                        <select name="objetivo" id="objetivo">
                            <option value="">-- Selecione --</option>
                            <option value="EM" <?= $objetivo == "EM" ? "selected" : "" ?>>Emagrecimento</option>
                            <option value="HI" <?= $objetivo == "HI" ? "selected" : "" ?>>Hipertrofia</option>
                            <option value="CO" <?= $objetivo == "CO" ? "selected" : "" ?>>Condicionamento</option>
                            <option value="RE" <?= $objetivo == "RE" ? "selected" : "" ?>>Reabilitação</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit">Efetivar Matrícula</button>
        </form>
    </div>
</div>

</body>
</html>