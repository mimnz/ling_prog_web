CREATE TABLE alunos (
    id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    data_nascimento DATE NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    modalidade VARCHAR(2) NOT NULL, /* MU=Musculação, FU=Funcional, AC=Aulas Coletivas */
    plano VARCHAR(1) NOT NULL,      /* M=Mensal, T=Trimestral, S=Semestral, A=Anual */
    anamnese TEXT NOT NULL,
    objetivo VARCHAR(2) NOT NULL,   /* EM=Emagrecimento, HI=Hipertrofia, CO=Condicionamento, RE=Reabilitação */
    CONSTRAINT pk_alunos PRIMARY KEY (id)
);