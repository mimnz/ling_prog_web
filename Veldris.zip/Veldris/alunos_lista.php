<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once("util/Conexao.php");

$conexao = Conexao::getConexao();

//Busca todos os alunos cadastrados
$sql = "SELECT * FROM alunos ORDER BY id DESC";
$stm = $conexao->prepare($sql);
$stm->execute();
$alunos = $stm->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="logo.png">
    <title>Veldris - Alunos Matriculados</title>
    <style>
        :root {
            --bg-color: #121212;
            --card-bg: rgba(30, 30, 30, 0.85);
            --primary-color: #ccff00;
            --text-color: #ffffff;
            --text-muted: #aaaaaa;
            --border-color: rgba(255, 255, 255, 0.1);
            --danger-color: #ff3333;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
            margin: 0;
            padding: 20px;
            background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('fundo.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            color: var(--primary-color);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 30px;
            text-shadow: 0 0 10px rgba(204, 255, 0, 0.5);
        }

        h3 {
            border-left: 4px solid var(--primary-color);
            padding-left: 10px;
            margin-top: 40px;
            text-transform: uppercase;
            font-size: 1.2rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.8);
        }

        .table-responsive {
            overflow-x: auto;
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 10px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            background-color: rgba(37, 37, 37, 0.9);
            color: var(--primary-color);
            font-weight: 600;
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }

        .btn-excluir {
            color: var(--danger-color);
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border: 1px solid var(--danger-color);
            border-radius: 4px;
            transition: 0.3s;
        }

        .btn-excluir:hover {
            background-color: var(--danger-color);
            color: #fff;
        }

        .btn-link {
            display: inline-block;
            background-color: var(--primary-color);
            color: #000;
            text-decoration: none;
            padding: 10px 20px;
            font-weight: bold;
            text-transform: uppercase;
            border-radius: 5px;
            transition: 0.3s;
        }

        .btn-link:hover {
            background-color: #b3df00;
            box-shadow: 0 0 15px rgba(204, 255, 0, 0.4);
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Veldris Academia</h1>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 40px;">
        <h3>Alunos Matriculados</h3>
        <a href="alunos.php" class="btn-link">Nova Inscrição</a>
    </div>
    
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>Telefone</th>
                    <th>Modalidade</th>
                    <th>Plano</th>
                    <th>Objetivo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($alunos as $a): ?>
                    <tr>
                        <td><?= $a["id"] ?></td>
                        <td><?= htmlspecialchars($a["nome"]) ?></td>
                        <td><?= htmlspecialchars($a["cpf"]) ?></td>
                        <td><?= htmlspecialchars($a["telefone"]) ?></td>
                        <td>
                            <?php
                                if($a['modalidade'] == 'MU') echo "Musculação";
                                else if($a['modalidade'] == 'FU') echo "Funcional";
                                else if($a['modalidade'] == 'AC') echo "Aulas Coletivas";
                            ?>
                        </td>
                        <td>
                            <?php
                                if($a['plano'] == 'M') echo "Mensal";
                                else if($a['plano'] == 'T') echo "Trimestral";
                                else if($a['plano'] == 'S') echo "Semestral";
                                else if($a['plano'] == 'A') echo "Anual";
                            ?>
                        </td>
                        <td>
                            <?php
                                if($a['objetivo'] == 'EM') echo "Emagrecimento";
                                else if($a['objetivo'] == 'HI') echo "Hipertrofia";
                                else if($a['objetivo'] == 'CO') echo "Condicionamento";
                                else if($a['objetivo'] == 'RE') echo "Reabilitação";
                            ?>
                        </td>
                        <td>
                            <a class="btn-excluir" href="alunos_excluir.php?id=<?= $a['id'] ?>"
                               onclick="return confirm('Confirma o cancelamento da matrícula deste aluno?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if(count($alunos) == 0): ?>
                    <tr><td colspan="8" style="text-align:center; color: var(--text-muted);">Nenhum aluno cadastrado.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>