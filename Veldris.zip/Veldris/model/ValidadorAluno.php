<?php

class ValidadorAluno {
    private array $erros = [];
    private PDO $conexao;

    // O validador precisa da conexão com o banco para testar se o CPF é repetido
    public function __construct(PDO $conexao) {
        $this->conexao = $conexao;
    }

    // Método principal que testa o objeto Aluno
    public function validar(Aluno $aluno): bool {
        // Validações de campos em branco (equivalente ao .trim() === '' do JS)
        if (empty(trim($aluno->getNome() ?? ''))) {
            $this->erros[] = "Informe o nome completo!";
        }
        if (empty(trim($aluno->getDataNasc() ?? ''))) {
            $this->erros[] = "Informe a data de nascimento!";
        }
        if (empty(trim($aluno->getTelefone() ?? ''))) {
            $this->erros[] = "Informe o telefone para contato!";
        }
        if (empty(trim($aluno->getModalidade() ?? ''))) {
            $this->erros[] = "Selecione uma modalidade!";
        }
        if (empty(trim($aluno->getPlano() ?? ''))) {
            $this->erros[] = "Selecione o plano do aluno!";
        }
        if (empty(trim($aluno->getAnamnese() ?? ''))) {
            $this->erros[] = "Informe o campo de anamnese/saúde para a segurança do aluno!";
        }
        if (empty(trim($aluno->getObjetivo() ?? ''))) {
            $this->erros[] = "Selecione o objetivo principal!";
        }

        // Validação do CPF + Checagem no Banco de Dados
        $cpf = trim($aluno->getCpf() ?? '');
        if (empty($cpf)) {
            $this->erros[] = "Informe o CPF!";
        } else {
            $sql = "SELECT id FROM alunos WHERE cpf = ?";
            $stm = $this->conexao->prepare($sql);
            $stm->execute([$cpf]);
            if (count($stm->fetchAll()) > 0) {
                $this->erros[] = "Este CPF já possui matrícula ativa!";
            }
        }

        // Se o array de erros continuar vazio, retorna TRUE (dados válidos)
        return empty($this->erros);
    }

    // Retorna a lista de erros encontrados para exibirmos na tela
    public function getErros(): array {
        return $this->erros;
    }
}