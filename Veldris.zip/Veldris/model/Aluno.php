<?php

class Aluno {
    private ?string $nome;
    private ?string $dataNasc;
    private ?string $cpf;
    private ?string $telefone;
    private ?string $modalidade;
    private ?string $plano;
    private ?string $anamnese;
    private ?string $objetivo;

    public function __construct($nome, $dataNasc, $cpf, $telefone, $modalidade, $plano, $anamnese, $objetivo) {
        $this->nome = $nome;
        $this->dataNasc = $dataNasc;
        $this->cpf = $cpf;
        $this->telefone = $telefone;
        $this->modalidade = $modalidade;
        $this->plano = $plano;
        $this->anamnese = $anamnese;
        $this->objetivo = $objetivo;
    }

    public function getNome(): ?string { return $this->nome; }
    public function getDataNasc(): ?string { return $this->dataNasc; }
    public function getCpf(): ?string { return $this->cpf; }
    public function getTelefone(): ?string { return $this->telefone; }
    public function getModalidade(): ?string { return $this->modalidade; }
    public function getPlano(): ?string { return $this->plano; }
    public function getAnamnese(): ?string { return $this->anamnese; }
    public function getObjetivo(): ?string { return $this->objetivo; }
}