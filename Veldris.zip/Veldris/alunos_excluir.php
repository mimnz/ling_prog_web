<?php

require_once("util/Conexao.php");

$id = 0;

//Verifica se o parâmetro 'id' foi enviado
if(isset($_GET['id'])) {
    $id = intval($_GET['id']);
}

if($id > 0) {
    $conexao = Conexao::getConexao();
    
    // Prepara a instrução SQL
    $sql = "DELETE FROM alunos WHERE id = ?";
    $stm = $conexao->prepare($sql);
    
    // executa o comando trocando o '?' pelo ID do aluno recebido
    // aqui o MySQL apaga definitivamente determinada linha da tabela 'alunos'
    $stm->execute([$id]);

    //depois de apagar, ele força o navegador a atualizar a página
    header("location: alunos_lista.php");
    exit;
} else {
    echo "<div style='color: white; background: #121212; height: 100vh; padding: 20px; font-family: sans-serif;'>";
    echo "Parâmetro ID inválido!<br><br>";
    echo "<a href='alunos_lista.php' style='color: #ccff00;'>Voltar para a listagem</a>";
    echo "</div>";
}