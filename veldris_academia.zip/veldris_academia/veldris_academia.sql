CREATE DATABASE IF NOT EXISTS veldris_academia
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE veldris_academia;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS turmas;
DROP TABLE IF EXISTS profissionais;
DROP TABLE IF EXISTS modalidades;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE modalidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(80) NOT NULL UNIQUE,
    descricao VARCHAR(500) NOT NULL,
    caminho_imagem VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE profissionais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    especialidade VARCHAR(100) NOT NULL,
    cref VARCHAR(30) NOT NULL UNIQUE,
    tipo CHAR(1) NOT NULL,
    caminho_foto VARCHAR(255) NULL,
    CONSTRAINT chk_profissional_tipo CHECK (tipo IN ('P', 'I'))
) ENGINE=InnoDB;

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    id_modalidade INT NOT NULL,
    id_profissional INT NOT NULL,
    dia_semana VARCHAR(20) NOT NULL,
    horario TIME NOT NULL,
    nivel CHAR(1) NOT NULL,
    vagas INT NOT NULL,
    CONSTRAINT chk_turma_nivel CHECK (nivel IN ('I', 'N', 'A', 'T')),
    CONSTRAINT chk_turma_vagas CHECK (vagas BETWEEN 1 AND 100),
    CONSTRAINT fk_turma_modalidade FOREIGN KEY (id_modalidade)
        REFERENCES modalidades(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_turma_profissional FOREIGN KEY (id_profissional)
        REFERENCES profissionais(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    telefone VARCHAR(20) NOT NULL,
    data_nascimento DATE NOT NULL,
    plano CHAR(1) NOT NULL,
    situacao_matricula CHAR(1) NOT NULL DEFAULT 'A',
    caminho_foto VARCHAR(255) NULL,
    id_turma INT NOT NULL,
    CONSTRAINT chk_cliente_plano CHECK (plano IN ('M', 'T', 'S', 'A')),
    CONSTRAINT chk_cliente_situacao CHECK (situacao_matricula IN ('A', 'I')),
    CONSTRAINT fk_cliente_turma FOREIGN KEY (id_turma)
        REFERENCES turmas(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

INSERT INTO modalidades (nome, descricao, caminho_imagem) VALUES
('Jiu-jítsu', 'Arte suave baseada em controle, projeções e finalizações. Desenvolve técnica, estratégia e confiança em todas as fases do combate.', 'img/modalidades/jiu-jitsu.png'),
('Muay thai', 'Treinamento completo de trocação com punhos, cotovelos, joelhos e chutes. Trabalha condicionamento, precisão e disciplina.', 'img/modalidades/muay-thai.png'),
('Boxe', 'Aulas de movimentação, defesa e combinações de golpes, com foco em agilidade, resistência e coordenação.', 'img/modalidades/boxe.png'),
('Karatê', 'Prática tradicional de bases, golpes e katas que fortalece postura, concentração, respeito e autocontrole.', 'img/modalidades/karate.png'),
('Taekwondo', 'Modalidade dinâmica conhecida pelos chutes rápidos e precisos. Desenvolve flexibilidade, velocidade e equilíbrio.', 'img/modalidades/taekwondo.png');

INSERT INTO profissionais (nome, telefone, especialidade, cref, tipo, caminho_foto) VALUES
('Caio Mendes', '(45) 99921-4410', 'Jiu-jítsu', 'CREF-PR 021845-G', 'I', NULL),
('Larissa Nogueira', '(45) 99815-2097', 'Muay thai', 'CREF-PR 018724-G', 'I', NULL),
('Rafael Martins', '(45) 99104-7632', 'Boxe', 'CREF-PR 023091-G', 'I', NULL),
('Aline Sato', '(45) 99761-3508', 'Karatê', 'CREF-PR 019553-G', 'I', NULL),
('Bruno Kim', '(45) 99227-8861', 'Taekwondo', 'CREF-PR 022408-G', 'I', NULL),
('Marina Alves', '(45) 99602-1145', 'Treinamento funcional', 'CREF-PR 025177-G', 'P', NULL),
('Diego Rocha', '(45) 99908-5623', 'Hipertrofia e força', 'CREF-PR 020366-G', 'P', NULL);

INSERT INTO turmas (nome, id_modalidade, id_profissional, dia_semana, horario, nivel, vagas) VALUES
('Jiu-jítsu Fundamentos', 1, 1, 'Segunda-feira', '18:30:00', 'I', 24),
('Jiu-jítsu Evolução', 1, 1, 'Quarta-feira', '20:00:00', 'N', 20),
('Muay Thai Start', 2, 2, 'Terça-feira', '19:00:00', 'I', 26),
('Muay Thai Performance', 2, 2, 'Quinta-feira', '20:30:00', 'N', 22),
('Boxe Técnica', 3, 3, 'Segunda-feira', '20:00:00', 'T', 24),
('Boxe Condicionamento', 3, 3, 'Sexta-feira', '18:30:00', 'I', 28),
('Karatê Essencial', 4, 4, 'Terça-feira', '18:00:00', 'I', 22),
('Karatê Avançado', 4, 4, 'Quinta-feira', '19:30:00', 'A', 18),
('Taekwondo Base', 5, 5, 'Quarta-feira', '18:00:00', 'I', 24),
('Taekwondo Dinâmico', 5, 5, 'Sábado', '10:00:00', 'T', 30);

INSERT INTO clientes
(nome, cpf, telefone, data_nascimento, plano, situacao_matricula, caminho_foto, id_turma) VALUES
('Amanda Ribeiro', '148.263.579-04', '(45) 99931-1140', '2003-05-17', 'S', 'A', NULL, 3),
('André Luiz Costa', '203.746.158-90', '(45) 99844-2307', '1998-11-02', 'A', 'A', NULL, 1),
('Beatriz Ferreira', '357.901.624-18', '(45) 99176-5042', '2006-03-28', 'T', 'A', NULL, 9),
('Carlos Eduardo Lima', '492.138.760-55', '(45) 99703-8891', '1995-07-09', 'M', 'A', NULL, 5),
('Camila Duarte', '516.274.930-02', '(45) 99218-7415', '2001-09-21', 'S', 'A', NULL, 7),
('Daniel Moreira', '624.809.351-77', '(45) 99650-3208', '1989-01-14', 'A', 'A', NULL, 2),
('Eduarda Freitas', '731.592.480-36', '(45) 99972-6731', '2004-12-06', 'T', 'A', NULL, 4),
('Felipe Santos', '845.306.271-49', '(45) 99101-9972', '1997-06-25', 'M', 'I', NULL, 6),
('Gabriela Oliveira', '908.461.357-21', '(45) 99836-1459', '2002-08-11', 'A', 'A', NULL, 10),
('Henrique Barbosa', '135.790.246-83', '(45) 99714-6064', '1993-04-30', 'S', 'A', NULL, 8),
('Isabela Ramos', '268.415.709-62', '(45) 99260-4382', '2005-10-19', 'T', 'A', NULL, 1),
('João Pedro Martins', '390.627.148-05', '(45) 99633-7810', '2000-02-07', 'M', 'A', NULL, 5);
