<?php

require_once(__DIR__ . "/../model/Cliente.php");

class ClienteService {

    public function validar(Cliente $cliente) {
        $erros = array();

        if(!$cliente->getNome())
            array_push($erros, "Informe o nome do cliente!");

        $cpfNumeros = preg_replace('/\D/', '', $cliente->getCpf() ?? '');
        if(strlen($cpfNumeros) !== 11)
            array_push($erros, "Informe um CPF com 11 números!");

        if(!$cliente->getTelefone())
            array_push($erros, "Informe o telefone!");

        if(!$cliente->getDataNascimento())
            array_push($erros, "Informe a data de nascimento!");

        if(!in_array($cliente->getPlano(), array('M', 'T', 'S', 'A')))
            array_push($erros, "Informe um plano válido!");

        if(!in_array($cliente->getSituacaoMatricula(), array('A', 'I')))
            array_push($erros, "Informe a situação da matrícula!");

        if(!$cliente->getTurma() || !$cliente->getTurma()->getId())
            array_push($erros, "Informe a turma principal!");

        return $erros;
    }
}
