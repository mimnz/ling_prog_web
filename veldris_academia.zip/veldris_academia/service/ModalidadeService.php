<?php

require_once(__DIR__ . "/../model/Modalidade.php");

class ModalidadeService {

    public function validar(Modalidade $modalidade) {
        $erros = array();

        if(!$modalidade->getNome())
            array_push($erros, "Informe o nome da modalidade!");

        if(!$modalidade->getDescricao())
            array_push($erros, "Informe a descrição da modalidade!");
        else if(strlen($modalidade->getDescricao()) > 500)
            array_push($erros, "A descrição deve ter no máximo 500 caracteres!");

        if(!$modalidade->getCaminhoImagem())
            array_push($erros, "Informe uma imagem para a modalidade!");

        return $erros;
    }
}
