<?php

require_once(__DIR__ . "/../model/Profissional.php");

class ProfissionalService {

    public function validar(Profissional $profissional) {
        $erros = array();

        if(!$profissional->getNome())
            array_push($erros, "Informe o nome do profissional!");
        if(!$profissional->getTelefone())
            array_push($erros, "Informe o telefone!");
        if(!$profissional->getEspecialidade())
            array_push($erros, "Informe a especialidade!");
        if(!$profissional->getCref())
            array_push($erros, "Informe o CREF!");
        if(!in_array($profissional->getTipo(), array('P', 'I')))
            array_push($erros, "Informe o tipo de profissional!");

        return $erros;
    }
}
