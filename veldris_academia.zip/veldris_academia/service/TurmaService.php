<?php

require_once(__DIR__ . "/../model/Turma.php");

class TurmaService {

    public function validar(Turma $turma) {
        $erros = array();

        if(!$turma->getNome())
            array_push($erros, "Informe o nome da turma!");
        if(!$turma->getModalidade() || !$turma->getModalidade()->getId())
            array_push($erros, "Informe a modalidade!");
        if(!$turma->getInstrutor() || !$turma->getInstrutor()->getId())
            array_push($erros, "Informe o instrutor!");
        if(!$turma->getDiaSemana())
            array_push($erros, "Informe o dia da semana!");
        if(!$turma->getHorario())
            array_push($erros, "Informe o horário!");
        if(!in_array($turma->getNivel(), array('I', 'N', 'A', 'T')))
            array_push($erros, "Informe o nível da turma!");
        if(!$turma->getVagas() || $turma->getVagas() < 1 || $turma->getVagas() > 100)
            array_push($erros, "A quantidade de vagas deve estar entre 1 e 100!");

        return $erros;
    }
}
