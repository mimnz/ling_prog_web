<?php
$paginaAtual = $_SERVER['REQUEST_URI'] ?? '';
function menuAtivo(string $trecho): string {
    global $paginaAtual;
    return strpos($paginaAtual, $trecho) !== false ? ' ativo' : '';
}
?>
<header class="topo">
    <a class="marca" href="<?= BASE_URL ?>/index.php" aria-label="Página inicial da Veldris">
        <img src="<?= BASE_URL ?>/img/logo-dragao.png" alt="Dragão verde da Veldris">
        <span>VELDRIS<small>academia</small></span>
    </a>

    <button class="menu-botao" type="button" aria-label="Abrir menu" aria-expanded="false">Menu</button>

    <nav class="navegacao" aria-label="Navegação principal">
        <a class="<?= menuAtivo('/index.php') ?>" href="<?= BASE_URL ?>/index.php">Início</a>
        <a class="<?= menuAtivo('/modalidades/') ?>" href="<?= BASE_URL ?>/view/modalidades/listar.php">Modalidades</a>
        <a class="<?= menuAtivo('/horarios/') ?>" href="<?= BASE_URL ?>/view/horarios/listar.php">Horários</a>
        <a class="<?= menuAtivo('/instrutores/') ?>" href="<?= BASE_URL ?>/view/instrutores/listar.php">Instrutores</a>
        <span class="separador-menu" aria-hidden="true"></span>
        <a class="<?= menuAtivo('/clientes/') ?>" href="<?= BASE_URL ?>/view/clientes/listar.php">Clientes</a>
        <a class="<?= menuAtivo('/turmas/') ?>" href="<?= BASE_URL ?>/view/turmas/listar.php">Turmas</a>
        <a class="<?= menuAtivo('/profissionais/') ?>" href="<?= BASE_URL ?>/view/profissionais/listar.php">Profissionais</a>
    </nav>
</header>
