    </main>
    <footer class="rodape">
        <div>
            <strong>VELDRIS</strong>
            <span>Foco. Força. Evolução.</span>
        </div>
        <p>Projeto escolar de CRUD em PHP e MySQL.</p>
    </footer>
    <script src="<?= BASE_URL ?>/assets/js/site.js"></script>
</body>
</html>
