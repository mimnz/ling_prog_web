<?php
require_once(__DIR__ . "/../../util/config.php");
$tituloPagina = $tituloPagina ?? 'Veldris Academia';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Veldris Academia — musculação e treinamento de artes marciais.">
    <title><?= h($tituloPagina) ?> | Veldris</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<?php require_once(__DIR__ . "/menu.php"); ?>
<main>
