<?php

require_once(__DIR__ . "/../../controller/ProfissionalController.php");

$profissionais = (new ProfissionalController())->listar();
$tituloPagina = 'Profissionais';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo"><div><p class="sobretitulo">Área administrativa</p><h1>Profissionais</h1><p>Gerencie instrutores de luta e personal trainers.</p></div></header>

<section class="secao secao-compacta">
    <div class="secao-cabecalho"><div><h2>Equipe cadastrada</h2><p><?= count($profissionais) ?> registro(s) encontrado(s).</p></div><a class="botao btn btn-success rounded-0" href="inserir.php">Novo profissional</a></div>
    <div class="tabela-caixa">
        <?php if(empty($profissionais)): ?><p class="vazio">Nenhum profissional cadastrado.</p><?php else: ?>
        <table class="table table-dark table-hover mb-0 align-middle">
            <thead><tr><th>Foto</th><th>Nome</th><th>Especialidade</th><th>Tipo</th><th>CREF</th><th>Telefone</th><th>Ações</th></tr></thead>
            <tbody>
                <?php foreach($profissionais as $profissional): ?>
                    <tr>
                        <td><?php if($profissional->getCaminhoFoto()): ?><img class="foto-tabela" src="<?= BASE_URL ?>/<?= h($profissional->getCaminhoFoto()) ?>" alt=""><?php else: ?><span class="avatar-inicial"><?= h(substr($profissional->getNome(),0,1)) ?></span><?php endif; ?></td>
                        <td><?= h($profissional->getNome()) ?></td>
                        <td><?= h($profissional->getEspecialidade()) ?></td>
                        <td><?= h($profissional->getTipoDesc()) ?></td>
                        <td><?= h($profissional->getCref()) ?></td>
                        <td><?= h($profissional->getTelefone()) ?></td>
                        <td class="tabela-acoes"><a class="acao-link" href="alterar.php?id=<?= $profissional->getId() ?>">Editar</a><a class="acao-link acao-excluir" data-confirmar="Excluir este profissional?" href="excluir.php?id=<?= $profissional->getId() ?>">Excluir</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
