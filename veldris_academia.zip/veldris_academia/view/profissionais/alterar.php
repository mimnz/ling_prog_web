<?php

require_once(__DIR__ . "/../../controller/ProfissionalController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$profissionalCont = new ProfissionalController();
$profissional = null;

if(isset($_POST['nome'])) {
    $id = is_numeric($_POST['id']) ? (int) $_POST['id'] : 0;
    $atual = $profissionalCont->buscarPorId($id);
    if(!$atual) { echo "ID do profissional inválido!<br><a href='listar.php'>Voltar</a>"; exit; }

    $upload = ImagemUtil::salvar($_FILES['foto'] ?? array(), 'profissionais');
    $profissional = new Profissional();
    $profissional->setId($id);
    $profissional->setNome(trim($_POST['nome']) ?: null);
    $profissional->setTelefone(trim($_POST['telefone']) ?: null);
    $profissional->setEspecialidade(trim($_POST['especialidade']) ?: null);
    $profissional->setCref(trim($_POST['cref']) ?: null);
    $profissional->setTipo(trim($_POST['tipo']) ?: null);
    $profissional->setCaminhoFoto($upload['caminho'] ?: $atual->getCaminhoFoto());

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = $profissionalCont->alterar($profissional);
        if(empty($erros)) { header("location: listar.php"); exit; }
        $msgErro = implode("<br>", $erros);
    }
} else {
    $id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
    $profissional = $profissionalCont->buscarPorId($id);
    if(!$profissional) { echo "ID do profissional inválido!<br><a href='listar.php'>Voltar</a>"; exit; }
}

require_once(__DIR__ . "/form.php");
