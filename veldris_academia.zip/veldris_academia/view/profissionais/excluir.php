<?php

require_once(__DIR__ . "/../../controller/ProfissionalController.php");

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $erro = (new ProfissionalController())->excluir((int) $_GET['id']);
    if(!$erro) { header("location: listar.php"); exit; }
    echo $erro . "<br><a href='listar.php'>Voltar</a>";
} else {
    echo "ID do profissional não informado!<br><a href='listar.php'>Voltar</a>";
}
