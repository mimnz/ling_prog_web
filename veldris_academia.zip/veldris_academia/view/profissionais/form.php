<?php

$editando = $profissional && $profissional->getId();
$tituloPagina = $editando ? 'Alterar profissional' : 'Novo profissional';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo"><div><p class="sobretitulo">Área administrativa</p><h1><?= $editando ? 'Alterar profissional' : 'Novo profissional' ?></h1><p>Cadastre instrutores e personal trainers. A foto pode ser adicionada agora ou depois.</p></div></header>

<section class="secao secao-compacta">
    <form class="formulario" method="post" enctype="multipart/form-data">
        <?php if($msgErro): ?><div class="alerta alert alert-danger"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $profissional ? $profissional->getId() : 0 ?>">
        <div class="form-grid">
            <div class="campo campo-completo"><label class="form-label" for="nome">Nome completo</label><input class="form-control" id="nome" name="nome" maxlength="120" value="<?= $profissional ? h($profissional->getNome()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="telefone">Telefone</label><input class="form-control" id="telefone" name="telefone" maxlength="20" value="<?= $profissional ? h($profissional->getTelefone()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="cref">CREF</label><input class="form-control" id="cref" name="cref" maxlength="30" value="<?= $profissional ? h($profissional->getCref()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="especialidade">Especialidade</label><input class="form-control" id="especialidade" name="especialidade" maxlength="100" placeholder="Ex.: Jiu-jítsu" value="<?= $profissional ? h($profissional->getEspecialidade()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="tipo">Tipo de profissional</label><select class="form-select" id="tipo" name="tipo"><option value="">Selecione</option><option value="I" <?= $profissional && $profissional->getTipo()==='I' ? 'selected' : '' ?>>Instrutor de luta</option><option value="P" <?= $profissional && $profissional->getTipo()==='P' ? 'selected' : '' ?>>Personal trainer</option></select></div>
            <div class="campo campo-completo"><label class="form-label" for="foto">Foto opcional</label><?php if($profissional && $profissional->getCaminhoFoto()): ?><img class="foto-atual" src="<?= BASE_URL ?>/<?= h($profissional->getCaminhoFoto()) ?>" alt="Foto atual"><?php endif; ?><input class="form-control" type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp"><small>JPG, PNG ou WEBP, até 5 MB.</small></div>
        </div>
        <div class="form-acoes"><button class="botao btn btn-success rounded-0" type="submit">Salvar profissional</button><a class="botao botao-secundario btn btn-outline-light rounded-0" href="listar.php">Cancelar</a></div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
