<?php

require_once(__DIR__ . "/../../model/Profissional.php");
require_once(__DIR__ . "/../../controller/ProfissionalController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$profissional = null;

if(isset($_POST['nome'])) {
    $upload = ImagemUtil::salvar($_FILES['foto'] ?? array(), 'profissionais');

    $profissional = new Profissional();
    $profissional->setId(0);
    $profissional->setNome(trim($_POST['nome']) ?: null);
    $profissional->setTelefone(trim($_POST['telefone']) ?: null);
    $profissional->setEspecialidade(trim($_POST['especialidade']) ?: null);
    $profissional->setCref(trim($_POST['cref']) ?: null);
    $profissional->setTipo(trim($_POST['tipo']) ?: null);
    $profissional->setCaminhoFoto($upload['caminho']);

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = (new ProfissionalController())->inserir($profissional);
        if(empty($erros)) { header("location: listar.php"); exit; }
        $msgErro = implode("<br>", $erros);
    }
}

require_once(__DIR__ . "/form.php");
