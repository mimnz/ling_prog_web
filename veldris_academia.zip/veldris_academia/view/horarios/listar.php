<?php

require_once(__DIR__ . "/../../controller/TurmaController.php");

$turmas = (new TurmaController())->listar();
$tituloPagina = 'Horários';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Organize seu treino</p>
        <h1>Horários</h1>
        <p>Confira as turmas abertas, o nível indicado e o profissional responsável por cada aula.</p>
    </div>
</header>

<section class="secao secao-compacta">
    <div class="tabela-caixa">
        <table>
            <thead>
                <tr><th>Dia</th><th>Horário</th><th>Turma</th><th>Modalidade</th><th>Instrutor</th><th>Nível</th><th>Vagas</th></tr>
            </thead>
            <tbody>
                <?php foreach($turmas as $turma): ?>
                    <tr>
                        <td><?= h($turma->getDiaSemana()) ?></td>
                        <td class="linha-destaque"><?= h(substr($turma->getHorario(), 0, 5)) ?></td>
                        <td><?= h($turma->getNome()) ?></td>
                        <td><?= h($turma->getModalidade()->getNome()) ?></td>
                        <td><?= h($turma->getInstrutor()->getNome()) ?></td>
                        <td><?= h($turma->getNivelDesc()) ?></td>
                        <td><?= h((string) $turma->getVagas()) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
