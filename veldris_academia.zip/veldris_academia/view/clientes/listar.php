<?php

require_once(__DIR__ . "/../../controller/ClienteController.php");

$clientes = (new ClienteController())->listar();
$tituloPagina = 'Clientes';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Área administrativa</p>
        <h1>Clientes</h1>
        <p>Cadastre matrículas e mantenha plano, situação e turma principal sempre atualizados.</p>
    </div>
</header>

<section class="secao secao-compacta">
    <div class="secao-cabecalho">
        <div><h2>Clientes cadastrados</h2><p><?= count($clientes) ?> registro(s) encontrado(s).</p></div>
        <a class="botao" href="inserir.php">Novo cliente</a>
    </div>

    <div class="tabela-caixa">
        <?php if(empty($clientes)): ?>
            <p class="vazio">Nenhum cliente cadastrado.</p>
        <?php else: ?>
            <table>
                <thead><tr><th>Foto</th><th>Nome</th><th>CPF</th><th>Plano</th><th>Turma principal</th><th>Situação</th><th>Ações</th></tr></thead>
                <tbody>
                    <?php foreach($clientes as $cliente): ?>
                        <tr>
                            <td>
                                <?php if($cliente->getCaminhoFoto()): ?>
                                    <img class="foto-tabela" src="<?= BASE_URL ?>/<?= h($cliente->getCaminhoFoto()) ?>" alt="">
                                <?php else: ?>
                                    <span class="avatar-inicial"><?= h(substr($cliente->getNome(), 0, 1)) ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?= h($cliente->getNome()) ?><br><small><?= h($cliente->getTelefone()) ?></small></td>
                            <td><?= h($cliente->getCpf()) ?></td>
                            <td><?= h($cliente->getPlanoDesc()) ?></td>
                            <td><?= h($cliente->getTurma()->getNome()) ?></td>
                            <td><span class="status <?= $cliente->getSituacaoMatricula() === 'I' ? 'status-inativo' : '' ?>"><?= h($cliente->getSituacaoMatriculaDesc()) ?></span></td>
                            <td class="tabela-acoes">
                                <a class="acao-link" href="alterar.php?id=<?= $cliente->getId() ?>">Editar</a>
                                <a class="acao-link acao-excluir" data-confirmar="Excluir este cliente?" href="excluir.php?id=<?= $cliente->getId() ?>">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
