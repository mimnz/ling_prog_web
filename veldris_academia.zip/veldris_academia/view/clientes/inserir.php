<?php

require_once(__DIR__ . "/../../model/Cliente.php");
require_once(__DIR__ . "/../../model/Turma.php");
require_once(__DIR__ . "/../../controller/ClienteController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$cliente = null;

if(isset($_POST['nome'])) {
    $nome = trim($_POST['nome']) ?: null;
    $cpf = trim($_POST['cpf']) ?: null;
    $telefone = trim($_POST['telefone']) ?: null;
    $nascimento = trim($_POST['data_nascimento']) ?: null;
    $plano = trim($_POST['plano']) ?: null;
    $situacao = trim($_POST['situacao_matricula']) ?: null;
    $idTurma = is_numeric($_POST['turma']) ? (int) $_POST['turma'] : null;

    $upload = ImagemUtil::salvar($_FILES['foto'] ?? array(), 'clientes');

    $cliente = new Cliente();
    $cliente->setId(0);
    $cliente->setNome($nome);
    $cliente->setCpf($cpf);
    $cliente->setTelefone($telefone);
    $cliente->setDataNascimento($nascimento);
    $cliente->setPlano($plano);
    $cliente->setSituacaoMatricula($situacao);
    $cliente->setCaminhoFoto($upload['caminho']);

    $turma = new Turma();
    $turma->setId($idTurma);
    $cliente->setTurma($turma);

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = (new ClienteController())->inserir($cliente);
        if(empty($erros)) {
            header("location: listar.php");
            exit;
        }
        $msgErro = implode("<br>", $erros);
    }
}

require_once(__DIR__ . "/form.php");
