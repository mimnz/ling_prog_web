<?php

require_once(__DIR__ . "/../../controller/ClienteController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$clienteCont = new ClienteController();
$cliente = null;

if(isset($_POST['nome'])) {
    $id = is_numeric($_POST['id']) ? (int) $_POST['id'] : 0;
    $atual = $clienteCont->buscarPorId($id);

    if(!$atual) {
        echo "ID do cliente inválido!<br><a href='listar.php'>Voltar</a>";
        exit;
    }

    $upload = ImagemUtil::salvar($_FILES['foto'] ?? array(), 'clientes');
    $caminhoFoto = $upload['caminho'] ?: $atual->getCaminhoFoto();

    $cliente = new Cliente();
    $cliente->setId($id);
    $cliente->setNome(trim($_POST['nome']) ?: null);
    $cliente->setCpf(trim($_POST['cpf']) ?: null);
    $cliente->setTelefone(trim($_POST['telefone']) ?: null);
    $cliente->setDataNascimento(trim($_POST['data_nascimento']) ?: null);
    $cliente->setPlano(trim($_POST['plano']) ?: null);
    $cliente->setSituacaoMatricula(trim($_POST['situacao_matricula']) ?: null);
    $cliente->setCaminhoFoto($caminhoFoto);

    $turma = new Turma();
    $turma->setId(is_numeric($_POST['turma']) ? (int) $_POST['turma'] : null);
    $cliente->setTurma($turma);

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = $clienteCont->alterar($cliente);
        if(empty($erros)) {
            header("location: listar.php");
            exit;
        }
        $msgErro = implode("<br>", $erros);
    }
} else {
    $id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
    $cliente = $clienteCont->buscarPorId($id);
    if(!$cliente) {
        echo "ID do cliente inválido!<br><a href='listar.php'>Voltar</a>";
        exit;
    }
}

require_once(__DIR__ . "/form.php");
