<?php

require_once(__DIR__ . "/../../controller/TurmaController.php");

$turmas = (new TurmaController())->listar();
$editando = $cliente && $cliente->getId();
$tituloPagina = $editando ? 'Alterar cliente' : 'Novo cliente';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div><p class="sobretitulo">Área administrativa</p><h1><?= $editando ? 'Alterar cliente' : 'Novo cliente' ?></h1><p>Preencha os dados da matrícula. A foto é opcional.</p></div>
</header>

<section class="secao secao-compacta">
    <form class="formulario" method="post" enctype="multipart/form-data">
        <?php if($msgErro): ?><div class="alerta"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $cliente ? $cliente->getId() : 0 ?>">

        <div class="form-grid">
            <div class="campo campo-completo"><label for="nome">Nome completo</label><input id="nome" name="nome" maxlength="120" value="<?= $cliente ? h($cliente->getNome()) : '' ?>" required></div>
            <div class="campo"><label for="cpf">CPF</label><input id="cpf" name="cpf" maxlength="14" placeholder="000.000.000-00" value="<?= $cliente ? h($cliente->getCpf()) : '' ?>" required></div>
            <div class="campo"><label for="telefone">Telefone</label><input id="telefone" name="telefone" maxlength="20" placeholder="(45) 99999-9999" value="<?= $cliente ? h($cliente->getTelefone()) : '' ?>" required></div>
            <div class="campo"><label for="data_nascimento">Data de nascimento</label><input type="date" id="data_nascimento" name="data_nascimento" value="<?= $cliente ? h($cliente->getDataNascimento()) : '' ?>" required></div>
            <div class="campo"><label for="plano">Plano</label><select id="plano" name="plano" required><option value="">Selecione</option><?php foreach(array('M'=>'Mensal','T'=>'Trimestral','S'=>'Semestral','A'=>'Anual') as $valor=>$texto): ?><option value="<?= $valor ?>" <?= $cliente && $cliente->getPlano() === $valor ? 'selected' : '' ?>><?= $texto ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label for="situacao_matricula">Situação da matrícula</label><select id="situacao_matricula" name="situacao_matricula" required><option value="A" <?= !$cliente || $cliente->getSituacaoMatricula() === 'A' ? 'selected' : '' ?>>Ativa</option><option value="I" <?= $cliente && $cliente->getSituacaoMatricula() === 'I' ? 'selected' : '' ?>>Inativa</option></select></div>
            <div class="campo"><label for="turma">Turma principal</label><select id="turma" name="turma" required><option value="">Selecione</option><?php foreach($turmas as $turma): ?><option value="<?= $turma->getId() ?>" <?= $cliente && $cliente->getTurma() && $cliente->getTurma()->getId() === $turma->getId() ? 'selected' : '' ?>><?= h($turma->getNome()) ?> — <?= h($turma->getDiaSemana()) ?> <?= h(substr($turma->getHorario(),0,5)) ?></option><?php endforeach; ?></select></div>
            <div class="campo campo-completo">
                <label for="foto">Foto opcional</label>
                <?php if($cliente && $cliente->getCaminhoFoto()): ?><img class="foto-atual" src="<?= BASE_URL ?>/<?= h($cliente->getCaminhoFoto()) ?>" alt="Foto atual"><?php endif; ?>
                <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp"><small>JPG, PNG ou WEBP, até 5 MB.</small>
            </div>
        </div>
        <div class="form-acoes"><button class="botao" type="submit">Salvar cliente</button><a class="botao botao-secundario" href="listar.php">Cancelar</a></div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
