<?php

require_once(__DIR__ . "/../../controller/TurmaController.php");

$turmas = (new TurmaController())->listar();
$editando = $cliente && $cliente->getId();
$tituloPagina = $editando ? 'Alterar cliente' : 'Novo cliente';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div><p class="sobretitulo">Área administrativa</p><h1><?= $editando ? 'Alterar cliente' : 'Novo cliente' ?></h1><p>Preencha os dados da matrícula. A foto é opcional.</p></div>
</header>

<section class="secao secao-compacta">
    <form class="formulario" method="post" enctype="multipart/form-data">
        <?php if($msgErro): ?><div class="alerta alert alert-danger"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $cliente ? $cliente->getId() : 0 ?>">

        <div class="form-grid">
            <div class="campo campo-completo"><label class="form-label" for="nome">Nome completo</label><input class="form-control" id="nome" name="nome" maxlength="120" value="<?= $cliente ? h($cliente->getNome()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="cpf">CPF</label><input class="form-control" id="cpf" name="cpf" maxlength="14" placeholder="000.000.000-00" value="<?= $cliente ? h($cliente->getCpf()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="telefone">Telefone</label><input class="form-control" id="telefone" name="telefone" maxlength="20" placeholder="(45) 99999-9999" value="<?= $cliente ? h($cliente->getTelefone()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="data_nascimento">Data de nascimento</label><input class="form-control" type="date" id="data_nascimento" name="data_nascimento" value="<?= $cliente ? h($cliente->getDataNascimento()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="plano">Plano</label><select class="form-select" id="plano" name="plano"><option value="">Selecione</option><?php foreach(array('M'=>'Mensal','T'=>'Trimestral','S'=>'Semestral','A'=>'Anual') as $valor=>$texto): ?><option value="<?= $valor ?>" <?= $cliente && $cliente->getPlano() === $valor ? 'selected' : '' ?>><?= $texto ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label class="form-label" for="situacao_matricula">Situação da matrícula</label><select class="form-select" id="situacao_matricula" name="situacao_matricula"><option value="A" <?= !$cliente || $cliente->getSituacaoMatricula() === 'A' ? 'selected' : '' ?>>Ativa</option><option value="I" <?= $cliente && $cliente->getSituacaoMatricula() === 'I' ? 'selected' : '' ?>>Inativa</option></select></div>
            <div class="campo"><label class="form-label" for="turma">Turma principal</label><select class="form-select" id="turma" name="turma"><option value="">Selecione</option><?php foreach($turmas as $turma): ?><option value="<?= $turma->getId() ?>" <?= $cliente && $cliente->getTurma() && $cliente->getTurma()->getId() === $turma->getId() ? 'selected' : '' ?>><?= h($turma->getNome()) ?> — <?= h($turma->getDiaSemana()) ?> <?= h(substr($turma->getHorario(),0,5)) ?></option><?php endforeach; ?></select></div>
            <div class="campo campo-completo">
                <label class="form-label" for="foto">Foto opcional</label>
                <?php if($cliente && $cliente->getCaminhoFoto()): ?><img class="foto-atual" src="<?= BASE_URL ?>/<?= h($cliente->getCaminhoFoto()) ?>" alt="Foto atual"><?php endif; ?>
                <input class="form-control" type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp"><small>JPG, PNG ou WEBP, até 5 MB.</small>
            </div>
        </div>
        <div class="form-acoes"><button class="botao btn btn-success rounded-0" type="submit">Salvar cliente</button><a class="botao botao-secundario btn btn-outline-light rounded-0" href="listar.php">Cancelar</a></div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
