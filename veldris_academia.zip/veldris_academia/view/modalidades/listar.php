<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");

$modalidades = (new ModalidadeController())->listar();
$tituloPagina = 'Modalidades';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div class="pagina-topo-acoes">
        <div>
            <p class="sobretitulo">Artes marciais</p>
            <h1>Modalidades</h1>
            <p>Consulte as modalidades disponíveis ou cadastre uma nova opção de aula.</p>
        </div>
        <a class="botao" href="inserir.php">Nova modalidade</a>
    </div>
</header>

<section class="secao">
    <div class="grade-modalidades">
        <?php foreach($modalidades as $modalidade): ?>
            <article class="card-modalidade">
                <img src="<?= BASE_URL ?>/<?= h($modalidade->getCaminhoImagem()) ?>" alt="Aula de <?= h($modalidade->getNome()) ?>">
                <div class="card-conteudo">
                    <h2><?= h($modalidade->getNome()) ?></h2>
                    <p><?= h($modalidade->getDescricao()) ?></p>
                    <div class="card-acoes">
                        <a class="acao-link" href="alterar.php?id=<?= $modalidade->getId() ?>">Editar</a>
                        <a class="acao-link acao-excluir" data-confirmar="Excluir esta modalidade?" href="excluir.php?id=<?= $modalidade->getId() ?>">Excluir</a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
