<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$modalidadeCont = new ModalidadeController();
$modalidade = null;

if(isset($_POST['nome'])) {
    $id = is_numeric($_POST['id']) ? (int) $_POST['id'] : 0;
    $atual = $modalidadeCont->buscarPorId($id);

    if(!$atual) {
        echo "ID da modalidade inválido!<br><a href='listar.php'>Voltar</a>";
        exit;
    }

    $upload = ImagemUtil::salvar($_FILES['imagem'] ?? array(), 'modalidades');
    $caminhoImagem = $upload['caminho'] ?: $atual->getCaminhoImagem();

    $modalidade = new Modalidade();
    $modalidade->setId($id);
    $modalidade->setNome(trim($_POST['nome']) ?: null);
    $modalidade->setDescricao(trim($_POST['descricao']) ?: null);
    $modalidade->setCaminhoImagem($caminhoImagem);

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = $modalidadeCont->alterar($modalidade);
        if(empty($erros)) {
            header("location: listar.php");
            exit;
        }
        $msgErro = implode("<br>", $erros);
    }
} else {
    $id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
    $modalidade = $modalidadeCont->buscarPorId($id);

    if(!$modalidade) {
        echo "ID da modalidade inválido!<br><a href='listar.php'>Voltar</a>";
        exit;
    }
}

require_once(__DIR__ . "/form.php");
