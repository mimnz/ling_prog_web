<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");

if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $erro = (new ModalidadeController())->excluir((int) $_GET['id']);

    if(!$erro) {
        header("location: listar.php");
        exit;
    }

    echo $erro . "<br><a href='listar.php'>Voltar</a>";
} else {
    echo "ID da modalidade não informado!<br><a href='listar.php'>Voltar</a>";
}
