<?php

require_once(__DIR__ . "/../../model/Modalidade.php");
require_once(__DIR__ . "/../../controller/ModalidadeController.php");
require_once(__DIR__ . "/../../util/ImagemUtil.php");

$msgErro = "";
$modalidade = null;

if(isset($_POST['nome'])) {
    $upload = ImagemUtil::salvar($_FILES['imagem'] ?? array(), 'modalidades');

    $modalidade = new Modalidade();
    $modalidade->setId(0);
    $modalidade->setNome(trim($_POST['nome']) ?: null);
    $modalidade->setDescricao(trim($_POST['descricao']) ?: null);
    $modalidade->setCaminhoImagem($upload['caminho']);

    if($upload['erro']) {
        $msgErro = $upload['erro'];
    } else {
        $erros = (new ModalidadeController())->inserir($modalidade);
        if(empty($erros)) {
            header("location: listar.php");
            exit;
        }
        $msgErro = implode("<br>", $erros);
    }
}

require_once(__DIR__ . "/form.php");
