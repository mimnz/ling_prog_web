<?php

$editando = $modalidade && $modalidade->getId();
$tituloPagina = $editando ? 'Alterar modalidade' : 'Nova modalidade';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Área administrativa</p>
        <h1><?= $editando ? 'Alterar modalidade' : 'Nova modalidade' ?></h1>
        <p>Informe o nome, a descrição e uma imagem que represente a aula.</p>
    </div>
</header>

<section class="secao secao-compacta">
    <form class="formulario" method="post" enctype="multipart/form-data">
        <?php if($msgErro): ?><div class="alerta"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $modalidade ? $modalidade->getId() : 0 ?>">

        <div class="form-grid">
            <div class="campo campo-completo">
                <label for="nome">Nome da modalidade</label>
                <input id="nome" name="nome" maxlength="80" value="<?= $modalidade ? h($modalidade->getNome()) : '' ?>" required>
            </div>

            <div class="campo campo-completo">
                <label for="descricao">Descrição</label>
                <textarea id="descricao" name="descricao" maxlength="500" rows="5" required><?= $modalidade ? h($modalidade->getDescricao()) : '' ?></textarea>
                <small>Escreva uma explicação curta para o card da modalidade.</small>
            </div>

            <div class="campo campo-completo">
                <label for="imagem">Imagem <?= $editando ? 'nova (opcional)' : '' ?></label>
                <?php if($modalidade && $modalidade->getCaminhoImagem()): ?>
                    <img class="imagem-modalidade-atual" src="<?= BASE_URL ?>/<?= h($modalidade->getCaminhoImagem()) ?>" alt="Imagem atual da modalidade">
                <?php endif; ?>
                <input type="file" id="imagem" name="imagem" accept="image/jpeg,image/png,image/webp" <?= $editando ? '' : 'required' ?>>
                <small>JPG, PNG ou WEBP, até 5 MB.</small>
            </div>
        </div>

        <div class="form-acoes">
            <button class="botao" type="submit">Salvar modalidade</button>
            <a class="botao botao-secundario" href="listar.php">Cancelar</a>
        </div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
