<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");

$modalidades = (new ModalidadeController())->listar();
$modalidadesInicio = array_slice($modalidades, 0, 8);
$tituloPagina = 'Início';
require_once(__DIR__ . "/../include/header.php");
?>

<section class="banner-home" aria-label="Recepção e área de treino da Academia Veldris"></section>

<section class="secao apresentacao-home">
    <div>
        <p class="sobretitulo">Treinos de segunda a sábado</p>
        <h1>Musculação e modalidades de luta.</h1>
    </div>
    <div class="apresentacao-texto">
        <p>Na Veldris você pode fazer musculação ou escolher entre diferentes modalidades de artes marciais. Há opções para quem está começando e para quem já treina.</p>
        <div class="acoes">
            <a class="botao" href="<?= BASE_URL ?>/view/horarios/listar.php">Consultar horários</a>
            <a class="botao botao-secundario" href="<?= BASE_URL ?>/view/modalidades/listar.php">Ver modalidades</a>
        </div>
    </div>
</section>

<section class="secao">
    <div class="secao-cabecalho">
        <div>
            <p class="sobretitulo">Artes marciais</p>
            <h2>Escolha sua modalidade</h2>
        </div>
        <p>Conheça as lutas disponíveis e veja qual delas combina mais com o tipo de treino que você procura.</p>
    </div>

    <div class="grade-modalidades">
        <?php foreach($modalidadesInicio as $modalidade): ?>
            <article class="card-modalidade">
                <img src="<?= BASE_URL ?>/<?= h($modalidade->getCaminhoImagem()) ?>" alt="Treino de <?= h($modalidade->getNome()) ?>">
                <div class="card-conteudo">
                    <h3><?= h($modalidade->getNome()) ?></h3>
                    <p><?= h($modalidade->getDescricao()) ?></p>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="modalidades-rodape">
        <a class="botao botao-secundario" href="<?= BASE_URL ?>/view/modalidades/listar.php">Ver todas as modalidades</a>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
