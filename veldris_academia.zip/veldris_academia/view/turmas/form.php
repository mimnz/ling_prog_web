<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");
require_once(__DIR__ . "/../../controller/ProfissionalController.php");

$modalidades = (new ModalidadeController())->listar();
$instrutores = (new ProfissionalController())->listarInstrutores();
$editando = $turma && $turma->getId();
$tituloPagina = $editando ? 'Alterar turma' : 'Nova turma';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo"><div><p class="sobretitulo">Área administrativa</p><h1><?= $editando ? 'Alterar turma' : 'Nova turma' ?></h1><p>Relacione a turma a uma modalidade cadastrada e a um instrutor de luta.</p></div></header>

<section class="secao secao-compacta">
    <form class="formulario" method="post">
        <?php if($msgErro): ?><div class="alerta"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $turma ? $turma->getId() : 0 ?>">
        <div class="form-grid">
            <div class="campo campo-completo"><label for="nome">Nome da turma</label><input id="nome" name="nome" maxlength="100" placeholder="Ex.: Jiu-jítsu Fundamentos" value="<?= $turma ? h($turma->getNome()) : '' ?>" required></div>
            <div class="campo"><label for="modalidade">Modalidade</label><select id="modalidade" name="modalidade" required><option value="">Selecione</option><?php foreach($modalidades as $modalidade): ?><option value="<?= $modalidade->getId() ?>" <?= $turma && $turma->getModalidade() && $turma->getModalidade()->getId()===$modalidade->getId() ? 'selected' : '' ?>><?= h($modalidade->getNome()) ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label for="instrutor">Instrutor</label><select id="instrutor" name="instrutor" required><option value="">Selecione</option><?php foreach($instrutores as $instrutor): ?><option value="<?= $instrutor->getId() ?>" <?= $turma && $turma->getInstrutor() && $turma->getInstrutor()->getId()===$instrutor->getId() ? 'selected' : '' ?>><?= h($instrutor->getNome()) ?> — <?= h($instrutor->getEspecialidade()) ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label for="dia_semana">Dia da semana</label><select id="dia_semana" name="dia_semana" required><option value="">Selecione</option><?php foreach(array('Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado') as $dia): ?><option value="<?= $dia ?>" <?= $turma && $turma->getDiaSemana()===$dia ? 'selected' : '' ?>><?= $dia ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label for="horario">Horário</label><input type="time" id="horario" name="horario" value="<?= $turma ? h(substr($turma->getHorario() ?? '',0,5)) : '' ?>" required></div>
            <div class="campo"><label for="nivel">Nível</label><select id="nivel" name="nivel" required><option value="">Selecione</option><?php foreach(array('I'=>'Iniciante','N'=>'Intermediário','A'=>'Avançado','T'=>'Todos os níveis') as $valor=>$texto): ?><option value="<?= $valor ?>" <?= $turma && $turma->getNivel()===$valor ? 'selected' : '' ?>><?= $texto ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label for="vagas">Quantidade de vagas</label><input type="number" id="vagas" name="vagas" min="1" max="100" value="<?= $turma ? h((string)$turma->getVagas()) : '' ?>" required></div>
        </div>
        <div class="form-acoes"><button class="botao" type="submit">Salvar turma</button><a class="botao botao-secundario" href="listar.php">Cancelar</a></div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
