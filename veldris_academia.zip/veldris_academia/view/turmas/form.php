<?php

require_once(__DIR__ . "/../../controller/ModalidadeController.php");
require_once(__DIR__ . "/../../controller/ProfissionalController.php");

$modalidades = (new ModalidadeController())->listar();
$instrutores = (new ProfissionalController())->listarInstrutores();
$editando = $turma && $turma->getId();
$tituloPagina = $editando ? 'Alterar turma' : 'Nova turma';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo"><div><p class="sobretitulo">Área administrativa</p><h1><?= $editando ? 'Alterar turma' : 'Nova turma' ?></h1><p>Relacione a turma a uma modalidade cadastrada e a um instrutor de luta.</p></div></header>

<section class="secao secao-compacta">
    <form class="formulario" method="post">
        <?php if($msgErro): ?><div class="alerta alert alert-danger"><?= $msgErro ?></div><?php endif; ?>
        <input type="hidden" name="id" value="<?= $turma ? $turma->getId() : 0 ?>">
        <div class="form-grid">
            <div class="campo campo-completo"><label class="form-label" for="nome">Nome da turma</label><input class="form-control" id="nome" name="nome" maxlength="100" placeholder="Ex.: Jiu-jítsu Fundamentos" value="<?= $turma ? h($turma->getNome()) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="modalidade">Modalidade</label><select class="form-select" id="modalidade" name="modalidade"><option value="">Selecione</option><?php foreach($modalidades as $modalidade): ?><option value="<?= $modalidade->getId() ?>" <?= $turma && $turma->getModalidade() && $turma->getModalidade()->getId()===$modalidade->getId() ? 'selected' : '' ?>><?= h($modalidade->getNome()) ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label class="form-label" for="instrutor">Instrutor</label><select class="form-select" id="instrutor" name="instrutor"><option value="">Selecione</option><?php foreach($instrutores as $instrutor): ?><option value="<?= $instrutor->getId() ?>" <?= $turma && $turma->getInstrutor() && $turma->getInstrutor()->getId()===$instrutor->getId() ? 'selected' : '' ?>><?= h($instrutor->getNome()) ?> — <?= h($instrutor->getEspecialidade()) ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label class="form-label" for="dia_semana">Dia da semana</label><select class="form-select" id="dia_semana" name="dia_semana"><option value="">Selecione</option><?php foreach(array('Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado') as $dia): ?><option value="<?= $dia ?>" <?= $turma && $turma->getDiaSemana()===$dia ? 'selected' : '' ?>><?= $dia ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label class="form-label" for="horario">Horário</label><input class="form-control" type="time" id="horario" name="horario" value="<?= $turma ? h(substr($turma->getHorario() ?? '',0,5)) : '' ?>"></div>
            <div class="campo"><label class="form-label" for="nivel">Nível</label><select class="form-select" id="nivel" name="nivel"><option value="">Selecione</option><?php foreach(array('I'=>'Iniciante','N'=>'Intermediário','A'=>'Avançado','T'=>'Todos os níveis') as $valor=>$texto): ?><option value="<?= $valor ?>" <?= $turma && $turma->getNivel()===$valor ? 'selected' : '' ?>><?= $texto ?></option><?php endforeach; ?></select></div>
            <div class="campo"><label class="form-label" for="vagas">Quantidade de vagas</label><input class="form-control" type="number" id="vagas" name="vagas" min="1" max="100" value="<?= $turma ? h((string)$turma->getVagas()) : '' ?>"></div>
        </div>
        <div class="form-acoes"><button class="botao btn btn-success rounded-0" type="submit">Salvar turma</button><a class="botao botao-secundario btn btn-outline-light rounded-0" href="listar.php">Cancelar</a></div>
    </form>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
