<?php

require_once(__DIR__ . "/../../model/Turma.php");
require_once(__DIR__ . "/../../model/Modalidade.php");
require_once(__DIR__ . "/../../model/Profissional.php");
require_once(__DIR__ . "/../../controller/TurmaController.php");

$msgErro = "";
$turma = null;

if(isset($_POST['nome'])) {
    $modalidade = new Modalidade();
    $modalidade->setId(is_numeric($_POST['modalidade']) ? (int) $_POST['modalidade'] : null);

    $instrutor = new Profissional();
    $instrutor->setId(is_numeric($_POST['instrutor']) ? (int) $_POST['instrutor'] : null);

    $turma = new Turma();
    $turma->setId(0);
    $turma->setNome(trim($_POST['nome']) ?: null);
    $turma->setModalidade($modalidade);
    $turma->setInstrutor($instrutor);
    $turma->setDiaSemana(trim($_POST['dia_semana']) ?: null);
    $turma->setHorario(trim($_POST['horario']) ?: null);
    $turma->setNivel(trim($_POST['nivel']) ?: null);
    $turma->setVagas(is_numeric($_POST['vagas']) ? (int) $_POST['vagas'] : null);

    $erros = (new TurmaController())->inserir($turma);
    if(empty($erros)) { header("location: listar.php"); exit; }
    $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
