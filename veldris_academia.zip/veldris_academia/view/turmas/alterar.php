<?php

require_once(__DIR__ . "/../../controller/TurmaController.php");

$msgErro = "";
$turmaCont = new TurmaController();
$turma = null;

if(isset($_POST['nome'])) {
    $modalidade = new Modalidade();
    $modalidade->setId(is_numeric($_POST['modalidade']) ? (int) $_POST['modalidade'] : null);

    $instrutor = new Profissional();
    $instrutor->setId(is_numeric($_POST['instrutor']) ? (int) $_POST['instrutor'] : null);

    $turma = new Turma();
    $turma->setId(is_numeric($_POST['id']) ? (int) $_POST['id'] : 0);
    $turma->setNome(trim($_POST['nome']) ?: null);
    $turma->setModalidade($modalidade);
    $turma->setInstrutor($instrutor);
    $turma->setDiaSemana(trim($_POST['dia_semana']) ?: null);
    $turma->setHorario(trim($_POST['horario']) ?: null);
    $turma->setNivel(trim($_POST['nivel']) ?: null);
    $turma->setVagas(is_numeric($_POST['vagas']) ? (int) $_POST['vagas'] : null);

    $erros = $turmaCont->alterar($turma);
    if(empty($erros)) { header("location: listar.php"); exit; }
    $msgErro = implode("<br>", $erros);
} else {
    $id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;
    $turma = $turmaCont->buscarPorId($id);
    if(!$turma) { echo "ID da turma inválido!<br><a href='listar.php'>Voltar</a>"; exit; }
}

require_once(__DIR__ . "/form.php");
