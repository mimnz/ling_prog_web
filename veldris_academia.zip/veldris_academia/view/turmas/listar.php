<?php

require_once(__DIR__ . "/../../controller/TurmaController.php");

$turmas = (new TurmaController())->listar();
$tituloPagina = 'Turmas';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo"><div><p class="sobretitulo">Área administrativa</p><h1>Turmas</h1><p>Cadastre e organize modalidade, instrutor, dia, horário, nível e vagas.</p></div></header>

<section class="secao secao-compacta">
    <div class="secao-cabecalho"><div><h2>Grade de turmas</h2><p><?= count($turmas) ?> turma(s) cadastrada(s).</p></div><a class="botao btn btn-success rounded-0" href="inserir.php">Nova turma</a></div>
    <div class="tabela-caixa">
        <?php if(empty($turmas)): ?><p class="vazio">Nenhuma turma cadastrada.</p><?php else: ?>
        <table class="table table-dark table-hover mb-0 align-middle">
            <thead><tr><th>Turma</th><th>Modalidade</th><th>Instrutor</th><th>Dia</th><th>Horário</th><th>Nível</th><th>Vagas</th><th>Ações</th></tr></thead>
            <tbody>
                <?php foreach($turmas as $turma): ?>
                    <tr>
                        <td><?= h($turma->getNome()) ?></td>
                        <td><?= h($turma->getModalidade()->getNome()) ?></td>
                        <td><?= h($turma->getInstrutor()->getNome()) ?></td>
                        <td><?= h($turma->getDiaSemana()) ?></td>
                        <td class="linha-destaque"><?= h(substr($turma->getHorario(),0,5)) ?></td>
                        <td><?= h($turma->getNivelDesc()) ?></td>
                        <td><?= h((string) $turma->getVagas()) ?></td>
                        <td class="tabela-acoes"><a class="acao-link" href="alterar.php?id=<?= $turma->getId() ?>">Editar</a><a class="acao-link acao-excluir" data-confirmar="Excluir esta turma?" href="excluir.php?id=<?= $turma->getId() ?>">Excluir</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
