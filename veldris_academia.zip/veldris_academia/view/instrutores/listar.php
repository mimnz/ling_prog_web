<?php

require_once(__DIR__ . "/../../controller/ProfissionalController.php");

$instrutores = (new ProfissionalController())->listarInstrutores();
$tituloPagina = 'Instrutores';
require_once(__DIR__ . "/../include/header.php");
?>

<header class="pagina-topo">
    <div>
        <p class="sobretitulo">Quem orienta seu treino</p>
        <h1>Instrutores</h1>
        <p>Profissionais responsáveis pelas aulas de artes marciais e pela evolução técnica de cada turma.</p>
    </div>
</header>

<section class="secao">
    <div class="grade-profissionais">
        <?php foreach($instrutores as $instrutor): ?>
            <article class="card-profissional">
                <?php if($instrutor->getCaminhoFoto()): ?>
                    <img src="<?= BASE_URL ?>/<?= h($instrutor->getCaminhoFoto()) ?>" alt="Foto de <?= h($instrutor->getNome()) ?>">
                <?php else: ?>
                    <div class="profissional-placeholder" aria-hidden="true"><?= h(substr($instrutor->getNome(), 0, 1)) ?></div>
                <?php endif; ?>
                <div class="profissional-info">
                    <small><?= h($instrutor->getEspecialidade()) ?></small>
                    <h2><?= h($instrutor->getNome()) ?></h2>
                    <p><?= h($instrutor->getCref()) ?></p>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>
