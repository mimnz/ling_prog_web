<?php

require_once(__DIR__ . "/Modalidade.php");
require_once(__DIR__ . "/Profissional.php");

class Turma {

    private ?int $id = null;
    private ?string $nome = null;
    private ?Modalidade $modalidade = null;
    private ?Profissional $instrutor = null;
    private ?string $diaSemana = null;
    private ?string $horario = null;
    private ?string $nivel = null;
    private ?int $vagas = null;

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): self { $this->id = $id; return $this; }

    public function getNome(): ?string { return $this->nome; }
    public function setNome(?string $nome): self { $this->nome = $nome; return $this; }

    public function getModalidade(): ?Modalidade { return $this->modalidade; }
    public function setModalidade(?Modalidade $modalidade): self { $this->modalidade = $modalidade; return $this; }

    public function getInstrutor(): ?Profissional { return $this->instrutor; }
    public function setInstrutor(?Profissional $instrutor): self { $this->instrutor = $instrutor; return $this; }

    public function getDiaSemana(): ?string { return $this->diaSemana; }
    public function setDiaSemana(?string $diaSemana): self { $this->diaSemana = $diaSemana; return $this; }

    public function getHorario(): ?string { return $this->horario; }
    public function setHorario(?string $horario): self { $this->horario = $horario; return $this; }

    public function getNivel(): ?string { return $this->nivel; }
    public function setNivel(?string $nivel): self { $this->nivel = $nivel; return $this; }

    public function getNivelDesc(): string {
        if($this->nivel === 'I') return 'Iniciante';
        if($this->nivel === 'N') return 'Intermediário';
        if($this->nivel === 'A') return 'Avançado';
        if($this->nivel === 'T') return 'Todos os níveis';
        return '';
    }

    public function getVagas(): ?int { return $this->vagas; }
    public function setVagas(?int $vagas): self { $this->vagas = $vagas; return $this; }
}
