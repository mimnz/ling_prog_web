<?php

require_once(__DIR__ . "/Turma.php");

class Cliente {

    private ?int $id = null;
    private ?string $nome = null;
    private ?string $cpf = null;
    private ?string $telefone = null;
    private ?string $dataNascimento = null;
    private ?string $plano = null;
    private ?string $situacaoMatricula = null;
    private ?string $caminhoFoto = null;
    private ?Turma $turma = null;

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): self { $this->id = $id; return $this; }

    public function getNome(): ?string { return $this->nome; }
    public function setNome(?string $nome): self { $this->nome = $nome; return $this; }

    public function getCpf(): ?string { return $this->cpf; }
    public function setCpf(?string $cpf): self { $this->cpf = $cpf; return $this; }

    public function getTelefone(): ?string { return $this->telefone; }
    public function setTelefone(?string $telefone): self { $this->telefone = $telefone; return $this; }

    public function getDataNascimento(): ?string { return $this->dataNascimento; }
    public function setDataNascimento(?string $dataNascimento): self { $this->dataNascimento = $dataNascimento; return $this; }

    public function getPlano(): ?string { return $this->plano; }
    public function setPlano(?string $plano): self { $this->plano = $plano; return $this; }

    public function getPlanoDesc(): string {
        $planos = array('M' => 'Mensal', 'T' => 'Trimestral', 'S' => 'Semestral', 'A' => 'Anual');
        return $planos[$this->plano] ?? '';
    }

    public function getSituacaoMatricula(): ?string { return $this->situacaoMatricula; }
    public function setSituacaoMatricula(?string $situacaoMatricula): self { $this->situacaoMatricula = $situacaoMatricula; return $this; }

    public function getSituacaoMatriculaDesc(): string {
        if($this->situacaoMatricula === 'A') return 'Ativa';
        if($this->situacaoMatricula === 'I') return 'Inativa';
        return '';
    }

    public function getCaminhoFoto(): ?string { return $this->caminhoFoto; }
    public function setCaminhoFoto(?string $caminhoFoto): self { $this->caminhoFoto = $caminhoFoto; return $this; }

    public function getTurma(): ?Turma { return $this->turma; }
    public function setTurma(?Turma $turma): self { $this->turma = $turma; return $this; }
}
