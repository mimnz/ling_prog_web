<?php

class Modalidade {

    private ?int $id = null;
    private ?string $nome = null;
    private ?string $descricao = null;
    private ?string $caminhoImagem = null;

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): self { $this->id = $id; return $this; }

    public function getNome(): ?string { return $this->nome; }
    public function setNome(?string $nome): self { $this->nome = $nome; return $this; }

    public function getDescricao(): ?string { return $this->descricao; }
    public function setDescricao(?string $descricao): self { $this->descricao = $descricao; return $this; }

    public function getCaminhoImagem(): ?string { return $this->caminhoImagem; }
    public function setCaminhoImagem(?string $caminhoImagem): self { $this->caminhoImagem = $caminhoImagem; return $this; }
}
