<?php

class Profissional {

    private ?int $id = null;
    private ?string $nome = null;
    private ?string $telefone = null;
    private ?string $especialidade = null;
    private ?string $cref = null;
    private ?string $tipo = null;
    private ?string $caminhoFoto = null;

    public function getId(): ?int { return $this->id; }
    public function setId(?int $id): self { $this->id = $id; return $this; }

    public function getNome(): ?string { return $this->nome; }
    public function setNome(?string $nome): self { $this->nome = $nome; return $this; }

    public function getTelefone(): ?string { return $this->telefone; }
    public function setTelefone(?string $telefone): self { $this->telefone = $telefone; return $this; }

    public function getEspecialidade(): ?string { return $this->especialidade; }
    public function setEspecialidade(?string $especialidade): self { $this->especialidade = $especialidade; return $this; }

    public function getCref(): ?string { return $this->cref; }
    public function setCref(?string $cref): self { $this->cref = $cref; return $this; }

    public function getTipo(): ?string { return $this->tipo; }
    public function setTipo(?string $tipo): self { $this->tipo = $tipo; return $this; }

    // Converte a letra salva no banco em um texto amigável para a tela.
    public function getTipoDesc(): string {
        if($this->tipo === 'P') return 'Personal trainer';
        if($this->tipo === 'I') return 'Instrutor de luta';
        return '';
    }

    public function getCaminhoFoto(): ?string { return $this->caminhoFoto; }
    public function setCaminhoFoto(?string $caminhoFoto): self { $this->caminhoFoto = $caminhoFoto; return $this; }
}
