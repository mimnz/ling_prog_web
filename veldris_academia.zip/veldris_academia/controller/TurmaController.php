<?php

require_once(__DIR__ . "/../dao/TurmaDAO.php");
require_once(__DIR__ . "/../service/TurmaService.php");

class TurmaController {

    private TurmaDAO $turmaDAO;
    private TurmaService $turmaService;

    public function __construct() {
        $this->turmaDAO = new TurmaDAO();
        $this->turmaService = new TurmaService();
    }

    public function listar() { return $this->turmaDAO->list(); }
    public function buscarPorId(int $id) { return $this->turmaDAO->findById($id); }

    public function inserir($turma) {
        $erros = $this->turmaService->validar($turma);
        if(empty($erros)) {
            $erroDAO = $this->turmaDAO->insert($turma);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function alterar($turma) {
        $erros = $this->turmaService->validar($turma);
        if(empty($erros)) {
            $erroDAO = $this->turmaDAO->update($turma);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function excluir(int $id) { return $this->turmaDAO->excluir($id); }
}
