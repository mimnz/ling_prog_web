<?php

require_once(__DIR__ . "/../dao/ProfissionalDAO.php");
require_once(__DIR__ . "/../service/ProfissionalService.php");

class ProfissionalController {

    private ProfissionalDAO $profissionalDAO;
    private ProfissionalService $profissionalService;

    public function __construct() {
        $this->profissionalDAO = new ProfissionalDAO();
        $this->profissionalService = new ProfissionalService();
    }

    public function listar() { return $this->profissionalDAO->list(); }
    public function listarInstrutores() { return $this->profissionalDAO->listInstrutores(); }
    public function buscarPorId(int $id) { return $this->profissionalDAO->findById($id); }

    public function inserir($profissional) {
        $erros = $this->profissionalService->validar($profissional);
        if(empty($erros)) {
            $erroDAO = $this->profissionalDAO->insert($profissional);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function alterar($profissional) {
        $erros = $this->profissionalService->validar($profissional);
        if(empty($erros)) {
            $erroDAO = $this->profissionalDAO->update($profissional);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function excluir(int $id) { return $this->profissionalDAO->excluir($id); }
}
