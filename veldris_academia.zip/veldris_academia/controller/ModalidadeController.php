<?php

require_once(__DIR__ . "/../dao/ModalidadeDAO.php");
require_once(__DIR__ . "/../service/ModalidadeService.php");

class ModalidadeController {

    private ModalidadeDAO $modalidadeDAO;
    private ModalidadeService $modalidadeService;

    public function __construct() {
        $this->modalidadeDAO = new ModalidadeDAO();
        $this->modalidadeService = new ModalidadeService();
    }

    public function listar() {
        return $this->modalidadeDAO->list();
    }

    public function buscarPorId(int $id) {
        return $this->modalidadeDAO->findById($id);
    }

    public function inserir($modalidade) {
        $erros = $this->modalidadeService->validar($modalidade);
        if(empty($erros)) {
            $erroDAO = $this->modalidadeDAO->insert($modalidade);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function alterar($modalidade) {
        $erros = $this->modalidadeService->validar($modalidade);
        if(empty($erros)) {
            $erroDAO = $this->modalidadeDAO->update($modalidade);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function excluir(int $id) {
        return $this->modalidadeDAO->excluir($id);
    }
}
