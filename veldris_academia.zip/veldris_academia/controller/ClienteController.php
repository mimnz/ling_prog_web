<?php

require_once(__DIR__ . "/../dao/ClienteDAO.php");
require_once(__DIR__ . "/../service/ClienteService.php");

class ClienteController {

    private ClienteDAO $clienteDAO;
    private ClienteService $clienteService;

    public function __construct() {
        $this->clienteDAO = new ClienteDAO();
        $this->clienteService = new ClienteService();
    }

    public function listar() { return $this->clienteDAO->list(); }
    public function buscarPorId(int $id) { return $this->clienteDAO->findById($id); }

    public function inserir($cliente) {
        $erros = $this->clienteService->validar($cliente);
        if(empty($erros)) {
            $erroDAO = $this->clienteDAO->insert($cliente);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function alterar($cliente) {
        $erros = $this->clienteService->validar($cliente);
        if(empty($erros)) {
            $erroDAO = $this->clienteDAO->update($cliente);
            if($erroDAO) array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function excluir(int $id) { return $this->clienteDAO->excluir($id); }
}
