<?php

require_once(__DIR__ . "/view/home/home.php");
