<?php

class ImagemUtil {

    public static function salvar($arquivo, $pasta) {
        if(!isset($arquivo['name']) || $arquivo['name'] == '')
            return array('caminho' => null, 'erro' => '');

        if($arquivo['error'] != 0)
            return array('caminho' => null, 'erro' => 'Não foi possível enviar a imagem.');

        if($arquivo['size'] > 5000000)
            return array('caminho' => null, 'erro' => 'A imagem deve ter no máximo 5 MB.');

        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        $extensoesPermitidas = array('jpg', 'jpeg', 'png', 'webp');

        if(!in_array($extensao, $extensoesPermitidas))
            return array('caminho' => null, 'erro' => 'Use uma imagem JPG, PNG ou WEBP.');

        $pastaDestino = __DIR__ . '/../img/uploads/' . $pasta . '/';
        if(!file_exists($pastaDestino))
            mkdir($pastaDestino, 0777, true);

        $nomeArquivo = time() . '.' . $extensao;
        $destino = $pastaDestino . $nomeArquivo;

        if(!move_uploaded_file($arquivo['tmp_name'], $destino))
            return array('caminho' => null, 'erro' => 'Não foi possível salvar a imagem.');

        $caminho = 'img/uploads/' . $pasta . '/' . $nomeArquivo;
        return array('caminho' => $caminho, 'erro' => '');
    }
}
