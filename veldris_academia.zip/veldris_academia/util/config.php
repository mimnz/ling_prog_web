<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

define("DB_HOST", "localhost");
define("DB_NAME", "veldris_academia");
define("DB_USER", "root");
define("DB_PASSWORD", "bancodedados");

define("AMB_DEV", true);

define("BASE_URL", "/veldris_academia");

function h(?string $texto): string {
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}
