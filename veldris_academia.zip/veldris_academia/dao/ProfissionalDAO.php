<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Profissional.php");

class ProfissionalDAO {

    public function list() {
        $sql = "SELECT * FROM profissionais ORDER BY nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }

    public function listInstrutores() {
        $sql = "SELECT * FROM profissionais WHERE tipo = 'I' ORDER BY nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }

    public function findById(int $id): ?Profissional {
        $sql = "SELECT * FROM profissionais WHERE id = ?";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        $profissionais = $this->map($stm->fetchAll());
        return !empty($profissionais) ? $profissionais[0] : null;
    }

    public function insert(Profissional $profissional) {
        try {
            $sql = "INSERT INTO profissionais
                    (nome, telefone, especialidade, cref, tipo, caminho_foto)
                    VALUES (:nome, :telefone, :especialidade, :cref, :tipo, :foto)";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $profissional->getNome());
            $stm->bindValue('telefone', $profissional->getTelefone());
            $stm->bindValue('especialidade', $profissional->getEspecialidade());
            $stm->bindValue('cref', $profissional->getCref());
            $stm->bindValue('tipo', $profissional->getTipo());
            $stm->bindValue('foto', $profissional->getCaminhoFoto());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o profissional. Verifique se o CREF já foi cadastrado.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Profissional $profissional) {
        try {
            $sql = "UPDATE profissionais SET nome = :nome, telefone = :telefone,
                    especialidade = :especialidade, cref = :cref, tipo = :tipo,
                    caminho_foto = :foto WHERE id = :id";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $profissional->getNome());
            $stm->bindValue('telefone', $profissional->getTelefone());
            $stm->bindValue('especialidade', $profissional->getEspecialidade());
            $stm->bindValue('cref', $profissional->getCref());
            $stm->bindValue('tipo', $profissional->getTipo());
            $stm->bindValue('foto', $profissional->getCaminhoFoto());
            $stm->bindValue('id', $profissional->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao alterar o profissional. Verifique os dados informados.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM profissionais WHERE id = ?";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";
        } catch(PDOException $e) {
            $erro = "Não é possível excluir um profissional que possui turmas.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
        $profissionais = array();
        foreach($dados as $d) {
            $profissional = new Profissional();
            $profissional->setId($d['id']);
            $profissional->setNome($d['nome']);
            $profissional->setTelefone($d['telefone']);
            $profissional->setEspecialidade($d['especialidade']);
            $profissional->setCref($d['cref']);
            $profissional->setTipo($d['tipo']);
            $profissional->setCaminhoFoto($d['caminho_foto']);
            array_push($profissionais, $profissional);
        }
        return $profissionais;
    }
}
