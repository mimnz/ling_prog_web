<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Turma.php");

class TurmaDAO {

    public function list() {
        $sql = "SELECT t.*, m.nome AS nome_modalidade, m.descricao AS descricao_modalidade,
                       m.caminho_imagem, p.nome AS nome_instrutor, p.telefone AS telefone_instrutor,
                       p.especialidade, p.cref, p.tipo, p.caminho_foto
                FROM turmas t
                JOIN modalidades m ON (m.id = t.id_modalidade)
                JOIN profissionais p ON (p.id = t.id_profissional)
                ORDER BY FIELD(t.dia_semana, 'Segunda-feira', 'Terça-feira', 'Quarta-feira',
                               'Quinta-feira', 'Sexta-feira', 'Sábado'), t.horario";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }

    public function findById(int $id): ?Turma {
        $sql = "SELECT t.*, m.nome AS nome_modalidade, m.descricao AS descricao_modalidade,
                       m.caminho_imagem, p.nome AS nome_instrutor, p.telefone AS telefone_instrutor,
                       p.especialidade, p.cref, p.tipo, p.caminho_foto
                FROM turmas t
                JOIN modalidades m ON (m.id = t.id_modalidade)
                JOIN profissionais p ON (p.id = t.id_profissional)
                WHERE t.id = ?";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        $turmas = $this->map($stm->fetchAll());
        return !empty($turmas) ? $turmas[0] : null;
    }

    public function insert(Turma $turma) {
        try {
            $sql = "INSERT INTO turmas
                    (nome, id_modalidade, id_profissional, dia_semana, horario, nivel, vagas)
                    VALUES (:nome, :modalidade, :instrutor, :dia, :horario, :nivel, :vagas)";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $turma->getNome());
            $stm->bindValue('modalidade', $turma->getModalidade()->getId());
            $stm->bindValue('instrutor', $turma->getInstrutor()->getId());
            $stm->bindValue('dia', $turma->getDiaSemana());
            $stm->bindValue('horario', $turma->getHorario());
            $stm->bindValue('nivel', $turma->getNivel());
            $stm->bindValue('vagas', $turma->getVagas());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a turma. Tente novamente.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Turma $turma) {
        try {
            $sql = "UPDATE turmas SET nome = :nome, id_modalidade = :modalidade,
                    id_profissional = :instrutor, dia_semana = :dia, horario = :horario,
                    nivel = :nivel, vagas = :vagas WHERE id = :id";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $turma->getNome());
            $stm->bindValue('modalidade', $turma->getModalidade()->getId());
            $stm->bindValue('instrutor', $turma->getInstrutor()->getId());
            $stm->bindValue('dia', $turma->getDiaSemana());
            $stm->bindValue('horario', $turma->getHorario());
            $stm->bindValue('nivel', $turma->getNivel());
            $stm->bindValue('vagas', $turma->getVagas());
            $stm->bindValue('id', $turma->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao alterar a turma. Tente novamente.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM turmas WHERE id = ?";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";
        } catch(PDOException $e) {
            $erro = "Não é possível excluir uma turma que possui clientes matriculados.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
        $turmas = array();
        foreach($dados as $d) {
            $modalidade = new Modalidade();
            $modalidade->setId($d['id_modalidade']);
            $modalidade->setNome($d['nome_modalidade']);
            $modalidade->setDescricao($d['descricao_modalidade']);
            $modalidade->setCaminhoImagem($d['caminho_imagem']);

            $instrutor = new Profissional();
            $instrutor->setId($d['id_profissional']);
            $instrutor->setNome($d['nome_instrutor']);
            $instrutor->setTelefone($d['telefone_instrutor']);
            $instrutor->setEspecialidade($d['especialidade']);
            $instrutor->setCref($d['cref']);
            $instrutor->setTipo($d['tipo']);
            $instrutor->setCaminhoFoto($d['caminho_foto']);

            $turma = new Turma();
            $turma->setId($d['id']);
            $turma->setNome($d['nome']);
            $turma->setModalidade($modalidade);
            $turma->setInstrutor($instrutor);
            $turma->setDiaSemana($d['dia_semana']);
            $turma->setHorario($d['horario']);
            $turma->setNivel($d['nivel']);
            $turma->setVagas($d['vagas']);
            array_push($turmas, $turma);
        }
        return $turmas;
    }
}
