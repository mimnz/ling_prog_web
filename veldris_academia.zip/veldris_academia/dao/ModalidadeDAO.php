<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Modalidade.php");

class ModalidadeDAO {

    public function list() {
        $sql = "SELECT * FROM modalidades ORDER BY nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }

    public function findById(int $id): ?Modalidade {
        $sql = "SELECT * FROM modalidades WHERE id = ?";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        $modalidades = $this->map($stm->fetchAll());
        return !empty($modalidades) ? $modalidades[0] : null;
    }

    public function insert(Modalidade $modalidade) {
        try {
            $sql = "INSERT INTO modalidades (nome, descricao, caminho_imagem)
                    VALUES (:nome, :descricao, :imagem)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $modalidade->getNome());
            $stm->bindValue('descricao', $modalidade->getDescricao());
            $stm->bindValue('imagem', $modalidade->getCaminhoImagem());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar a modalidade. Verifique se o nome já foi cadastrado.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Modalidade $modalidade) {
        try {
            $sql = "UPDATE modalidades
                    SET nome = :nome, descricao = :descricao, caminho_imagem = :imagem
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $modalidade->getNome());
            $stm->bindValue('descricao', $modalidade->getDescricao());
            $stm->bindValue('imagem', $modalidade->getCaminhoImagem());
            $stm->bindValue('id', $modalidade->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao alterar a modalidade. Verifique os dados informados.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM modalidades WHERE id = ?";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";
        } catch(PDOException $e) {
            $erro = "Não é possível excluir uma modalidade que possui turmas cadastradas.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
        $modalidades = array();
        foreach($dados as $d) {
            $modalidade = new Modalidade();
            $modalidade->setId($d['id']);
            $modalidade->setNome($d['nome']);
            $modalidade->setDescricao($d['descricao']);
            $modalidade->setCaminhoImagem($d['caminho_imagem']);
            array_push($modalidades, $modalidade);
        }
        return $modalidades;
    }
}
