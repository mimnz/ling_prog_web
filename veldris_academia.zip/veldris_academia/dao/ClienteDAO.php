<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Cliente.php");

class ClienteDAO {

    public function list() {
        $sql = $this->sqlBase() . " ORDER BY c.nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }

    public function findById(int $id): ?Cliente {
        $sql = $this->sqlBase() . " WHERE c.id = ?";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);
        $clientes = $this->map($stm->fetchAll());
        return !empty($clientes) ? $clientes[0] : null;
    }

    private function sqlBase(): string {
        return "SELECT c.*, t.nome AS nome_turma, t.dia_semana, t.horario, t.nivel, t.vagas,
                       t.id_modalidade, m.nome AS nome_modalidade, m.descricao AS descricao_modalidade,
                       m.caminho_imagem, t.id_profissional, p.nome AS nome_instrutor,
                       p.telefone AS telefone_instrutor, p.especialidade, p.cref, p.tipo,
                       p.caminho_foto AS foto_instrutor
                FROM clientes c
                JOIN turmas t ON (t.id = c.id_turma)
                JOIN modalidades m ON (m.id = t.id_modalidade)
                JOIN profissionais p ON (p.id = t.id_profissional)";
    }

    public function insert(Cliente $cliente) {
        try {
            $sql = "INSERT INTO clientes
                    (nome, cpf, telefone, data_nascimento, plano, situacao_matricula, caminho_foto, id_turma)
                    VALUES (:nome, :cpf, :telefone, :nascimento, :plano, :situacao, :foto, :turma)";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $cliente->getNome());
            $stm->bindValue('cpf', $cliente->getCpf());
            $stm->bindValue('telefone', $cliente->getTelefone());
            $stm->bindValue('nascimento', $cliente->getDataNascimento());
            $stm->bindValue('plano', $cliente->getPlano());
            $stm->bindValue('situacao', $cliente->getSituacaoMatricula());
            $stm->bindValue('foto', $cliente->getCaminhoFoto());
            $stm->bindValue('turma', $cliente->getTurma()->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao salvar o cliente. Verifique se o CPF já foi cadastrado.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function update(Cliente $cliente) {
        try {
            $sql = "UPDATE clientes SET nome = :nome, cpf = :cpf, telefone = :telefone,
                    data_nascimento = :nascimento, plano = :plano,
                    situacao_matricula = :situacao, caminho_foto = :foto,
                    id_turma = :turma WHERE id = :id";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue('nome', $cliente->getNome());
            $stm->bindValue('cpf', $cliente->getCpf());
            $stm->bindValue('telefone', $cliente->getTelefone());
            $stm->bindValue('nascimento', $cliente->getDataNascimento());
            $stm->bindValue('plano', $cliente->getPlano());
            $stm->bindValue('situacao', $cliente->getSituacaoMatricula());
            $stm->bindValue('foto', $cliente->getCaminhoFoto());
            $stm->bindValue('turma', $cliente->getTurma()->getId());
            $stm->bindValue('id', $cliente->getId());
            $stm->execute();
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao alterar o cliente. Verifique os dados informados.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    public function excluir(int $id) {
        try {
            $sql = "DELETE FROM clientes WHERE id = ?";
            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";
        } catch(PDOException $e) {
            $erro = "Erro ao excluir o cliente. Tente novamente.";
            if(AMB_DEV) $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados) {
        $clientes = array();
        foreach($dados as $d) {
            $modalidade = new Modalidade();
            $modalidade->setId($d['id_modalidade']);
            $modalidade->setNome($d['nome_modalidade']);
            $modalidade->setDescricao($d['descricao_modalidade']);
            $modalidade->setCaminhoImagem($d['caminho_imagem']);

            $instrutor = new Profissional();
            $instrutor->setId($d['id_profissional']);
            $instrutor->setNome($d['nome_instrutor']);
            $instrutor->setTelefone($d['telefone_instrutor']);
            $instrutor->setEspecialidade($d['especialidade']);
            $instrutor->setCref($d['cref']);
            $instrutor->setTipo($d['tipo']);
            $instrutor->setCaminhoFoto($d['foto_instrutor']);

            $turma = new Turma();
            $turma->setId($d['id_turma']);
            $turma->setNome($d['nome_turma']);
            $turma->setDiaSemana($d['dia_semana']);
            $turma->setHorario($d['horario']);
            $turma->setNivel($d['nivel']);
            $turma->setVagas($d['vagas']);
            $turma->setModalidade($modalidade);
            $turma->setInstrutor($instrutor);

            $cliente = new Cliente();
            $cliente->setId($d['id']);
            $cliente->setNome($d['nome']);
            $cliente->setCpf($d['cpf']);
            $cliente->setTelefone($d['telefone']);
            $cliente->setDataNascimento($d['data_nascimento']);
            $cliente->setPlano($d['plano']);
            $cliente->setSituacaoMatricula($d['situacao_matricula']);
            $cliente->setCaminhoFoto($d['caminho_foto']);
            $cliente->setTurma($turma);
            array_push($clientes, $cliente);
        }
        return $clientes;
    }
}
