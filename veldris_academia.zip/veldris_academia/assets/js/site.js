//menu hamburguer
const botaoMenu = document.querySelector('.menu-botao');
const navegacao = document.querySelector('.navegacao');

if (botaoMenu && navegacao) {
    botaoMenu.addEventListener('click', () => {
        const aberto = navegacao.classList.toggle('aberta');
        botaoMenu.setAttribute('aria-expanded', aberto ? 'true' : 'false');
    });
}

// confirma exclusões para evitar clique acidental
document.querySelectorAll('[data-confirmar]').forEach((link) => {
    link.addEventListener('click', (evento) => {
        if (!window.confirm(link.dataset.confirmar))
            evento.preventDefault();
    });
});
