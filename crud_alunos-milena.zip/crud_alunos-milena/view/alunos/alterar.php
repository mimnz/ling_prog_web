<?php

require_once(__DIR__ . "/../../controller/AlunoController.php");

$msgErro = "";
$aluno = NULL;

$alunoCont = new AlunoController();

if(isset($_POST['nome'])) {
    $id = is_numeric($_POST['id']);
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $estrang = trim($_POST['estrangeiro']) ? trim($_POST['estrangeiro']) : NULL;
    $idCurso = is_numeric($_POST['curso']) ? $_POST['curso'] : NULL; 

    $aluno = new Aluno();
    $aluno->setId($_POST["id"]);
    $aluno->setNome($nome);
    $aluno->setIdade($idade);
    $aluno->setEstrangeiro($estrang);

    $curso = new Curso();
    $curso->setId($idCurso);
    $aluno->setCurso($curso);

    $erros = $alunoCont->alterar($aluno);
    if(empty($erros)) 
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
    
} else {

    $id = 0;

    if(isset($_GET['id']))
        $id = $_GET['id'];

    $aluno = $alunoCont->buscarPorId($id);
    if(!$aluno) {
        echo "ID do aluno inválido.<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}
 
require_once(__DIR__) . "/form.php";

