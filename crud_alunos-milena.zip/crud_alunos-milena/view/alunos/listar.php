<?php

require_once(__DIR__ . "/../../controller/AlunoController.php");

//Buscar os alunos -> origem: base de dados
$alunoCont = new AlunoController();
$alunos = $alunoCont->listar();
//print_r($alunos);

//Inclui o cabeçalho da página
require_once(__DIR__ . "/../include/header.php");
?>

<head>
    <style>
                /* Configurações Gerais */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333333;
            margin: 0;
            padding: 20px;
        }

        h3 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 20px;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }

        /* Botão Inserir */
        a[href="inserir.php"] {
            display: inline-block;
            background-color: #2ecc71;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 4px;
            margin-bottom: 20px;
            transition: background-color 0.2s ease;
        }

        a[href="inserir.php"]:hover {
            background-color: #27ae60;
        }

        /* Tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden; /* Garante que as bordas arredondadas funcionem */
            margin-top: 10px;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
        }

        /* Cabeçalho da Tabela */
        th {
            background-color: #34495e;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
        }

        /* Linhas da Tabela */
        tr {
            border-bottom: 1px solid #eeeeee;
        }

        /* Efeito zebra (linhas alternadas) */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* Efeito de passar o mouse na linha */
        tr:hover {
            background-color: #f1f4f6;
        }

        /* Estilo para a última linha não ter borda inferior */
        table tr:last-child {
            border-bottom: none;
        }

        /* Alinhamento dos ícones de ação */
        td a img {
            width: 20px;
            height: 20px;
            transition: transform 0.2s ease;
            vertical-align: middle;
        }

        td a img:hover {
            transform: scale(1.15); /* Dá um leve zoom ao passar o mouse */
        }

        /* Ajuste das colunas de botões para ficarem centralizadas e menores */
        th:nth-last-child(1), th:nth-last-child(2),
        td:nth-last-child(1), td:nth-last-child(2) {
            text-align: center;
            width: 50px;
        }

    </style>
</head>

<body>

<h3>Listagem de alunos</h3>

<a href="inserir.php">Inserir</a>

<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Idade</th>
        <th>Estrangeiro</th>
        <th>Curso</th>
        <th>Editar</th>
        <th>Excluir</th>
    </tr>

    <?php foreach($alunos as $a): ?>
        <tr>
            <td><?= $a->getId() ?></td>
            <td><?= $a->getNome() ?></td>
            <td><?= $a->getIdade() ?></td>
            <td><?= $a->getEstrangeiroDesc() ?></td>
            <td><?= $a->getCurso() ?></td>
            <td>
                <a href="alterar.php?id=<?=  $a->getId() ?>">
                    <img src="../../img/btn_editar.png" alt="">
                </a>    
            </td>
            <td>
                <a href="excluir.php?id=<?= $a->getId() ?>"
                    onclick="return confirm('Você tem certeza que deseja excluir esse usuário?');">
                    <img src="../../img/btn_excluir.png" alt="">
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
    

</table>

</body>


<?php
//Inclui o rodapé da página
require_once(__DIR__ . "/../include/footer.php");
?>

    
