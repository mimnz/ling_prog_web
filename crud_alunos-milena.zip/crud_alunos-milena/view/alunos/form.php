<?php

require_once(__DIR__ . "/../../controller/CursoController.php");

$cursoCont = new CursoController();
$cursos = $cursoCont->listar();
//print_r($cursos);

require_once(__DIR__ . "/../include/header.php");
?>

<head>
    <style>
        /* Configurações Gerais */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333333;
            margin: 0;
            padding: 20px;
        }

        h3 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 20px;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Container do Formulário */
        form {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto 20px auto;
        }

        /* Grupos de campos (divs) */
        form div {
            margin-bottom: 20px;
        }

        /* Rótulos (Labels) */
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #4a5568;
            font-size: 14px;
        }

        /* Campos de Entrada (Inputs e Selects) */
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 5px;
            font-size: 15px;
            color: #334155;
            background-color: #ffffff;
            box-sizing: border-box; /* Garante que o padding não quebre a largura */
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        /* Efeito de Clique no Campo */
        input[type="text"]:focus,
        input[type="number"]:focus,
        select:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
            outline: none;
        }

        /* Botão Gravar */
        button[type="submit"] {
            width: 100%;
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            margin-top: 10px;
        }

        button[type="submit"]:hover {
            background-color: #2980b9;
        }

        /* Mensagem de Erro */
        .error-message {
            max-width: 500px;
            margin: 0 auto 20px auto;
            padding: 12px;
            background-color: #fde8e8;
            border-left: 4px solid #e74c3c;
            border-radius: 4px;
            font-weight: 500;
        }

        /* Botão Voltar */
        a[href="listar.php"] {
            display: block;
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
            color: #7f8c8d;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        a[href="listar.php"]:hover {
            color: #333333;
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <h3>Inserir aluno</h3>

    <form action="" method="POST">

        <div>
            <label for="txtNome">Nome: </label>
            <input type="text" id="txtNome" name="nome" 
                placeholder="Informe o nome"
                value="<?= isset($aluno) ? $aluno->getNome() : '' ?>">
        </div>

        <div>
            <label for="txtIdade">Idade: </label>
            <input type="number" id="txtIdade" name="idade" 
                placeholder="Informe a idade"
                value="<?= isset($aluno) ? $aluno->getIdade() : '' ?>">
        </div>

        <div>
            <label for="selEstrang">Estrangeiro: </label>
            <select name="estrangeiro" id="selEstrang">
                <option value="">Selecione</option>
                <option value="S" <?= isset($aluno) && $aluno->getEstrangeiro() == 'S' ? 'selected' : '' ?> >
                    Sim</option>
                <option value="N" <?= isset($aluno) && $aluno->getEstrangeiro() == 'N' ? 'selected' : '' ?> >
                    Não</option>
            </select>
        </div>

        <div>
            <label for="selCurso">Curso: </label>
            <select name="curso" id="selCurso">
                <option value="">Selecione</option>

                <!-- Cursos criados de forma dinâmica -->
                <?php foreach($cursos as $c): ?>
                    <option value="<?= $c->getId() ?>"
                        <?php 
                            if(isset($aluno) && $aluno->getCurso()->getId() == $c->getId())
                                echo "selected";
                        ?>
                    >
                    <?= $c ?></option>        
                <?php endforeach; ?>    

            </select>
        </div>

        <div>
            <input type="hidden" name="id" value="<?=  $aluno ? $aluno->getId() : 0 ?>">
        </div>

        <div>
            <button type="submit">Gravar</button>
        </div>
    </form>

    <?php if (!empty($msgErro)): ?>
        <div class="error-message" style="color: red;">
            <?= $msgErro ?>
        </div>
    <?php endif; ?>

    <a href="listar.php">Voltar</a>

</body>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>
